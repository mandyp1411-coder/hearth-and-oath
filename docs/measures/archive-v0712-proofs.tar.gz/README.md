# Hearth & Oath v0.71.2 closed proof package

Frozen source: f82160cae5561f851f99c3c7fb1274fec04a30f7.
FAST: {'filesTotal': 244, 'filesTerminal': 244, 'filesPassed': 241, 'filesFailed': 3, 'filesBlocked': 0, 'filesNotRun': 0, 'passed': 3208, 'failed': 0, 'skipped': 4}.
SLOW: {'filesTotal': 36, 'filesTerminal': 36, 'filesPassed': 35, 'filesFailed': 1, 'filesBlocked': 0, 'filesNotRun': 0, 'passed': 741, 'failed': 0, 'skipped': 1}.
Final lane counts are taken once from closed reports; skips remain skips.
Both immutable source/output guards passed before packaging.

The source-engine handoff has 16 passing cases, 14 genuine Old Rules fixture
states and 22 public commands. It does not execute browser/storage/offline UI.
The separate 71/71 archive test record is the original unpatched baseline,
not an additional final-overlay suite. The built patched archive and the
handoff source are bound by the same runtime hash.

The pinned archive build records 262553396 hosted
bytes below its 256MiB limit. Only its small loader/manifest is hosted as the
old-rules alias. Large standalone HTML, Site archives, source bundles, QA
worktrees, artwork, music and offline parts are excluded here.

The owner reported public archive version 1 opened in actual Chrome (source
43ee1a8b, tree 848a699, runtime f4d05cc7). The retained actual main v0.71.1/105
slot export has complete-file SHA256 feb4b10aec9a5afb8f72e047e0a24ff1c45a5e2e775e988e2433acdb635c78a4.
The public archive import attempt hung in Cua and the user interrupted it.
There was no completed browser roundtrip and no retry. Main v0.71.2 publication
was pending at preparation. Explicit optional records, if supplied, retain
their own statuses; no success is inferred from their presence.
Single final native compiled startup checker: PASS.
Original auxiliary capture-summary parser: FAIL;
its complete original failure/seals remain unchanged. The selected semantic
result is parsed from both complete documents in the same closed stdout,
with all raw bytes consumed; no checker was re-executed.
Its raw semantic result and actual process/seals are retained when included.
A prior cleanliness guard stopped before spawn (zero checker executions);
its report and disposable residue-quarantine metadata remain separate.
The other 29 offline checks remain NOT RUN for this frozen snapshot.
Human farmer playtest: NOT RUN. The formal complete software gate is not
certified by this bundle. No v0.72 widening is authorized by these records.

All selected inputs were read stably and verified against their recorded
seals where available. Live logs/partial checkpoints are excluded. Original
paths are retained; see proof-path-map.json. Tar/gzip metadata is normalized;
two independent builds and a full member readback must agree.
