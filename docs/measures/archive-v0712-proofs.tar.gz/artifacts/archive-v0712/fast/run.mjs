// Artifact-only v0.71.2 FAST verifier. Do not start until the release is frozen/built.
// Uses the exact official FAST inventory; each Node file owns both reporters.
import { readdir, readFile, writeFile, stat, mkdir } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';
import path from 'node:path';

const ownDirectory = path.dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2), value = name => { const index = args.indexOf(name); return index < 0 ? null : args[index + 1]; };
const valued = new Set(['--root', '--out', '--baseline', '--expected-head', '--file-timeout-ms', '--expected-fast-files']);
for (let i = 0; i < args.length; i++) {
  if (valued.has(args[i])) { if (!args[++i] || args[i].startsWith('--')) throw Error('Missing option value.'); }
  else if (args[i] !== '--capture-baseline') throw Error('Unknown option: ' + args[i]);
}
const root = path.resolve(value('--root') || '/workspace/scratch/68d171ec368e/hearth-and-oath');
const out = path.resolve(value('--out') || path.join(root, 'artifacts/archive-v0712/fast'));
const baselinePath = path.resolve(value('--baseline') || path.join(out, 'baseline.json'));
const fileTimeoutMs = Number(value('--file-timeout-ms') || 900000);
if (!Number.isSafeInteger(fileTimeoutMs) || fileTimeoutMs < 1000) throw Error('Invalid file timeout.');
const capture = path.join(ownDirectory, 'capture-test.mjs');
const { runtimeIdentity, verificationIdentity, gitIdentity, hashFile, sha256, validateOfflineIdentity, treeFiles, contentIdentity } = await import(pathToFileURL(path.join(root, 'scripts/lib/release-identity.mjs')));
const { runReleaseProcess } = await import(pathToFileURL(path.join(root, 'scripts/lib/release-process.mjs')));
const { parseTestResults, classifyTestOutcome, aggregateStatus } = await import(pathToFileURL(path.join(root, 'scripts/lib/release-contract.mjs')));
const snapshot = async () => ({ runtime: await runtimeIdentity(root), verification: await verificationIdentity(root), content: await contentIdentity(root, await treeFiles(root, 'content')), git: gitIdentity(root), offline: await validateOfflineIdentity(root) });
const infrastructure = async () => ({ runner: await hashFile(fileURLToPath(import.meta.url)), capture: await hashFile(capture) });
async function absent(file) { try { await stat(file); throw Error('Refusing to overwrite evidence: ' + file); } catch (error) { if (error.code !== 'ENOENT') throw error; } }
await mkdir(out, { recursive: true });
if (args.includes('--capture-baseline')) {
  await absent(baselinePath);
  const source = await snapshot();
  if (source.offline.version !== '0.71.2') throw Error('The built artifact is not v0.71.2.');
  if (value('--expected-head') && source.git.head !== value('--expected-head')) throw Error('Expected HEAD differs from the frozen release.');
  await writeFile(baselinePath, JSON.stringify({ schemaVersion: 1, capturedAt: new Date().toISOString(), root, source, infrastructure: await infrastructure() }, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify({ baselinePath, head: source.git.head, runtime: source.runtime, verification: source.verification, content: source.content, artifactSha256: source.offline.sha256 }));
  process.exit(0);
}
const captured = JSON.parse(await readFile(baselinePath, 'utf8'));
const baseline = captured.source || captured.initial || captured;
const expectedHead = value('--expected-head') || baseline.git?.head || baseline.head;
if (!expectedHead) throw Error('An exact frozen HEAD is required.');
function inputError(source) {
  for (const key of ['runtime', 'verification', 'offline', ...(baseline.content ? ['content'] : [])]) if (JSON.stringify(source[key]) !== JSON.stringify(baseline[key])) return 'Frozen release ' + key + ' inputs changed';
  return source.git.head === expectedHead ? null : 'Frozen release HEAD changed';
}
const source = await snapshot(), originalInfrastructure = await infrastructure();
if (source.offline.version !== '0.71.2') throw Error('The frozen built artifact is not v0.71.2.');
if (inputError(source)) throw Error(inputError(source));
if (captured.infrastructure && JSON.stringify(captured.infrastructure) !== JSON.stringify(originalInfrastructure)) throw Error('Verifier infrastructure changed after baseline capture.');
const laneSource = await readFile(path.join(root, 'scripts/test-lanes.mjs'), 'utf8');
function literalSet(name) {
  const match = laneSource.match(new RegExp('export const ' + name + ' = new Set\\(\\[([\\s\\S]*?)\\]\\);'));
  if (!match) throw Error('Missing literal ' + name + ' inventory');
  const names = [...match[1].replace(/\/\/[^\n]*/g, '').matchAll(/'([^']+)'/g)].map(row => row[1]);
  if (!names.length || names.some(name => !/^[a-z0-9.-]+\.test\.js$/.test(name))) throw Error('Invalid official lane inventory');
  return new Set(names);
}
const slow = literalSet('SLOW'), debt = literalSet('KNOWN_DEBT');
for (const file of debt) slow.add(file);
const all = (await readdir(path.join(root, 'tests'))).filter(file => file.endsWith('.test.js')).sort();
const files = all.filter(file => !slow.has(file)).map(file => 'tests/' + file), slowCount = all.filter(file => slow.has(file)).length + 1;
const official = execFileSync(process.execPath, ['scripts/test-lanes.mjs', 'list'], { cwd: root, encoding: 'utf8' });
if (official !== `fast: ${files.length} files\nslow: ${slowCount} files\n` || files.length < 1 || slowCount < 1) throw Error('Official FAST inventory mismatch');
if (value('--expected-fast-files') && files.length !== Number(value('--expected-fast-files'))) throw Error('Frozen expected FAST file count differs from official inventory.');
const discovery = { command: [process.execPath, 'scripts/test-lanes.mjs', 'list'], output: official, laneSourceSha256: sha256(laneSource), inventorySha256: sha256(JSON.stringify(files)), files: files.length, officialSlowFiles: slowCount, slow: [...slow].sort(), knownDebt: [...debt].sort() };
const report = { schemaVersion: 2, lane: 'fast', proof: 'v0.71.2 frozen release candidate', version: source.offline.version, root, outputRoot: out, startedAt: new Date().toISOString(), status: 'NOT RUN', source, expectedHead, infrastructure: originalInfrastructure, baselinePath, node: process.version, platform: process.platform, arch: process.arch, concurrency: 4, fileTimeoutMs, discovery, tests: files.map(file => ({ file, status: 'NOT RUN', reason: 'File has not completed in this run.' })) };
let next = 0, stopped = false, stopReason = null, writeQueue = Promise.resolve();
const children = new Map();
function stop(signal) { stopped = true; stopReason = 'Interrupted by ' + signal + '; uncompleted results are NOT RUN.'; for (const child of children.values()) child?.stop(); }
process.on('SIGINT', () => stop('SIGINT')); process.on('SIGTERM', () => stop('SIGTERM'));
function counts() { return { filesTotal: files.length, filesTerminal: report.tests.filter(row => row.status !== 'NOT RUN').length, filesPassed: report.tests.filter(row => row.status === 'PASS').length, filesFailed: report.tests.filter(row => row.status === 'FAIL').length, filesBlocked: report.tests.filter(row => row.status === 'ENVIRONMENT BLOCKED').length, filesNotRun: report.tests.filter(row => row.status === 'NOT RUN').length, passed: report.tests.reduce((n, row) => n + (row.passed || 0), 0), failed: report.tests.reduce((n, row) => n + (row.failed || 0), 0), skipped: report.tests.reduce((n, row) => n + (row.skipped || 0), 0) }; }
function checkpoint() { const text = JSON.stringify({ ...report, status: 'NOT RUN', immutableSourceStatus: 'NOT RUN', immutableOutputStatus: 'NOT RUN', stopReason, summary: counts() }, null, 2) + '\n'; writeQueue = writeQueue.then(() => writeFile(path.join(out, 'checkpoint.partial.json'), text)); return writeQueue; }
function metadata(info) { return { dev: info.dev, ino: info.ino, bytes: info.size, birthtimeMs: info.birthtimeMs, mtimeMs: info.mtimeMs, ctimeMs: info.ctimeMs }; }
async function seal(file) { const before = metadata(await stat(file)), hash = await hashFile(file), after = metadata(await stat(file)); if (JSON.stringify(before) !== JSON.stringify(after)) throw Error('Output changed while sealing ' + file); return { path: file, sha256: hash, metadata: after }; }
function tapSummary(text) {
  const match = text.match(/(?:^|\n)1\.\.(\d+)\n# tests (\d+)\n# suites (\d+)\n# pass (\d+)\n# fail (\d+)\n# cancelled (\d+)\n# skipped (\d+)\n# todo (\d+)\n# duration_ms ([0-9.]+)\s*$/);
  if (!match) throw Error('TAP lacks a terminal root plan and complete summary');
  const keys = ['plan', 'tests', 'suites', 'passed', 'failed', 'cancelled', 'skipped', 'todo', 'durationMs'], summary = Object.fromEntries(keys.map((key, i) => [key, Number(match[i + 1])]));
  if (summary.plan <= 0 || summary.tests <= 0 || summary.passed + summary.failed + summary.cancelled + summary.skipped + summary.todo !== summary.tests) throw Error('TAP terminal totals do not reconcile');
  return summary;
}
await absent(path.join(out, 'report.json')); await writeFile(path.join(out, 'inventory.json'), JSON.stringify(discovery, null, 2) + '\n', { flag: 'wx' }); await checkpoint();
async function worker(id) {
  while (!stopped) {
    try { await stat(path.join(out, 'STOP')); stopped = true; stopReason = 'STOP marker requested a clean boundary; pending files remain NOT RUN.'; return; } catch (error) { if (error.code !== 'ENOENT') throw error; }
    const index = next++; if (index >= files.length) return;
    const file = files[index], stem = file.replace(/[^a-z0-9.-]/gi, '_');
    const log = path.join(out, stem + '.log'), resultsLog = path.join(out, stem + '.results.jsonl'), tapLog = path.join(out, stem + '.tap'), completion = path.join(out, stem + '.completion.json'), processLog = path.join(out, stem + '.process.json'), transport = path.join(out, stem + '.transport-live.log');
    for (const output of [log, resultsLog, tapLog, completion, processLog, transport]) await absent(output);
    const wrapperArgs = [capture, tapLog, processLog, file], startedAt = new Date().toISOString(); console.log('START ' + id + ' ' + file);
    const transportResult = await runReleaseProcess(process.execPath, wrapperArgs, { cwd: root, log: transport, timeoutMs: fileTimeoutMs, onChild: child => { if (child) children.set(id, child); else children.delete(id); } });
    let actual = null; try { actual = JSON.parse(await readFile(processLog, 'utf8')); } catch {}
    const result = { ...transportResult, ...(actual ? { code: actual.code, signal: actual.signal, error: actual.error || transportResult.error } : {}) };
    if (transportResult.code !== 0 && result.code === 0) result.error = 'Reporter capture wrapper failed after actual Node process completion';
    if (!actual?.processCompleted) result.error ||= 'Actual Node completion proof is unavailable';
    const outputText = result.stdout;
    await writeFile(log, outputText, { flag: 'wx' }); await writeFile(resultsLog, outputText, { flag: 'wx' });
    let stats, tap = null, parseError = null, tapError = null, outputError = null, proofByteMismatch = false; const evidence = [];
    try { stats = parseTestResults(outputText); } catch (error) { stats = { passed: 0, failed: 1, skipped: 0, results: 0 }; parseError = String(error); }
    try {
      const tapText = await readFile(tapLog, 'utf8'); tap = tapSummary(tapText);
      if (stats.results < tap.tests || stats.results > tap.tests + tap.suites) throw Error('Reporter and TAP terminal result counts disagree');
      if (actual && (Buffer.byteLength(outputText) !== actual.stdoutBytes || sha256(outputText) !== actual.stdoutSha256 || Buffer.byteLength(tapText) !== actual.stderrBytes || sha256(tapText) !== actual.stderrSha256)) { proofByteMismatch = true; throw Error('Reporter bytes differ from the in-memory actual-process completion proof'); }
    } catch (error) { tapError = String(error); }
    try {
      for (const output of [log, resultsLog, tapLog, ...(actual ? [processLog] : [])]) {
        const proof = await seal(output); evidence.push(proof);
        const expected = output === log || output === resultsLog ? sha256(outputText) : output === tapLog ? actual?.stderrSha256 : null;
        if (expected && proof.sha256 !== expected) { proofByteMismatch = true; throw Error('Persisted reporter bytes differ from captured process bytes: ' + output); }
      }
    } catch (error) { outputError = String(error); }
    let status = classifyTestOutcome(result, stats);
    if (status === 'PASS' && (tapError || outputError || tap.failed || tap.cancelled || tap.skipped || tap.todo)) status = 'FAIL';
    const row = { file, status: stopped && !stats.failed ? 'NOT RUN' : status, worker: id, startedAt, completedAt: new Date().toISOString(), command: actual?.command || [process.execPath, '--test', file], ...stats, actualProcess: actual, captureWrapper: { command: [process.execPath, ...wrapperArgs], code: transportResult.code, signal: transportResult.signal, error: transportResult.error }, tap, tapError, outputError, proofByteMismatch, evidence, code: result.code, signal: result.signal, error: result.error, parseError, timedOut: result.timedOut, durationMs: result.durationMs, log, resultsLog, tapLog, processCompleted: !!actual?.processCompleted };
    if (stopped) row.reason = stopReason;
    report.tests[index] = row; await writeFile(completion, JSON.stringify(row, null, 2) + '\n', { flag: 'wx' }); await checkpoint();
    console.log(row.status + ' ' + file + ' ' + row.passed + 'pass ' + row.failed + 'fail ' + row.skipped + 'skip ' + row.durationMs + 'ms' + (tapError ? ' TAP:' + tapError : ''));
  }
}
const outcomes = await Promise.allSettled([0, 1, 2, 3].map(async id => { try { await worker(id); } catch (error) { report.infrastructureError ||= String(error); stop('verification infrastructure failure'); throw error; } }));
await writeQueue;
report.finishedAt = new Date().toISOString(); report.after = await snapshot(); report.inputError = inputError(report.after);
if (!report.inputError && JSON.stringify(report.after.content) !== JSON.stringify(source.content)) report.inputError = 'Frozen content inputs changed';
report.infrastructureAfter = await infrastructure(); if (JSON.stringify(report.infrastructureAfter) !== JSON.stringify(originalInfrastructure)) report.inputError ||= 'Verifier infrastructure changed';
report.immutableSourceStatus = report.inputError ? 'FAIL' : 'PASS'; report.outputChanges = [];
for (const row of report.tests) for (const old of row.evidence || []) { try { const current = await seal(old.path); if (JSON.stringify(old) !== JSON.stringify(current)) report.outputChanges.push({ file: row.file, path: old.path, reason: 'Output metadata/checksum changed after process completion' }); } catch (error) { report.outputChanges.push({ file: row.file, path: old.path, reason: String(error) }); } }
report.immutableOutputStatus = report.outputChanges.length ? 'FAIL' : 'PASS'; report.stopReason = stopReason; report.summary = counts(); report.testStatus = aggregateStatus(report.tests);
report.status = report.infrastructureError || report.inputError || report.outputChanges.length ? 'FAIL' : stopped ? 'NOT RUN' : report.testStatus;
// Evidence repair never converts a gameplay assertion failure to a pass and
// never overwrites this run. Only damaged proof files are candidates for rerun.
report.byteDamagedProofCandidates = [...new Set([...report.outputChanges.map(row => row.file), ...report.tests.filter(row => row.proofByteMismatch).map(row => row.file)])].filter(file => { const row = report.tests.find(row => row.file === file); return row.actualProcess?.processCompleted && row.actualProcess.code === 0 && !row.actualProcess.signal && !row.actualProcess.error && row.failed === 0 && row.skipped === 0; });
report.workerOutcomes = outcomes.map(row => row.status === 'fulfilled' ? { status: row.status } : { status: row.status, reason: String(row.reason) });
await writeFile(path.join(out, 'report.json'), JSON.stringify(report, null, 2) + '\n', { flag: 'wx' }); await writeFile(path.join(out, 'checkpoint.json'), JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ status: report.status, immutableSourceStatus: report.immutableSourceStatus, immutableOutputStatus: report.immutableOutputStatus, summary: report.summary }));
process.exitCode = report.status === 'PASS' ? 0 : report.status === 'NOT RUN' ? 2 : 1;
