"""Package closed v0.71.2 proofs; writes only this ignored final-proofs directory."""
from __future__ import annotations
import argparse, gzip, hashlib, io, json, os, subprocess, tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'artifacts/archive-v0712'
OUT = BASE / 'final-proofs'
EXPECTED = 'f82160cae5561f851f99c3c7fb1274fec04a30f7'
PINNED = '065d54cd91c8cfea390ba0f71fb046351153d6fa'
DOWNLOAD = 'feb4b10aec9a5afb8f72e047e0a24ff1c45a5e2e775e988e2433acdb635c78a4'
ARCHIVE = OUT / 'archive-v0712-proofs.tar.gz'
MANIFEST = OUT / 'archive-v0712-proof-manifest.json'
sha = lambda data: hashlib.sha256(data).hexdigest()
load = lambda file: json.loads(file.read_text())

def stamp(file):
    s = file.stat()
    return s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns

def stable(file):
    if file.is_symlink() or not file.is_file():
        raise ValueError('Not a regular proof file: ' + str(file))
    before = stamp(file)
    if before[2] > 25 * 1024 * 1024:
        raise ValueError('Large build/media/source file excluded: ' + str(file))
    data = file.read_bytes()
    if stamp(file) != before:
        raise ValueError('Proof changed while reading: ' + str(file))
    return data, before

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--all-guards-closed', required=True, action='store_true')
    ap.add_argument('--native-closed', action='store_true', help='Include and verify the single final native checker after its process/seals close.')
    ap.add_argument('--optional-file', action='append', default=[], help='Explicit closed supplemental file beneath artifacts/, without inferred success.')
    args = ap.parse_args()
    freeze = load(BASE / 'freeze.json')
    if freeze['freeze']['commit'] != EXPECTED or freeze['freeze']['version'] != '0.71.2':
        raise ValueError('Unexpected frozen release.')
    if subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() != EXPECTED:
        raise ValueError('Primary HEAD is no longer the frozen release.')
    if subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True).strip():
        raise ValueError('Primary tracked tree is not clean.')
    files = {}
    def add(relative):
        file = Path(relative)
        if file.is_absolute(): file = file.relative_to(ROOT)
        name = file.as_posix()
        if '..' in file.parts or name.startswith('/'):
            raise ValueError('Unsafe proof path.')
        full = ROOT / file
        data, metadata = stable(full)
        if name in files and files[name]['data'] != data:
            raise ValueError('Proof path collision: ' + name)
        files[name] = {'data': data, 'source': full, 'stamp': metadata}
        return data
    def check_seal(directory, record, path_key='file'):
        raw = Path(record[path_key])
        file = raw if raw.is_absolute() else directory / raw
        # SLOW records use /artifacts/... as a root-relative display path.
        if raw.is_absolute() and raw.as_posix().startswith('/artifacts/'):
            file = ROOT / raw.as_posix().lstrip('/')
        data = add(file)
        size = record.get('bytes', record.get('metadata', {}).get('bytes'))
        if size is not None and len(data) != size:
            raise ValueError('Proof byte count differs: ' + str(file))
        if sha(data) != record['sha256']:
            raise ValueError('Proof checksum differs: ' + str(file))
        return data
    lane_reports = {}
    for name, count in [('fast', 244), ('slow', 36)]:
        directory = BASE / name
        if not (directory / 'report.json').is_file():
            raise ValueError(name + ': final report is not present; lane is still open.')
        report = load(directory / 'report.json')
        if not report.get('finishedAt') or len(report['tests']) != count or report['summary']['filesNotRun'] != 0:
            raise ValueError(name + ': all official files must be terminal before packaging.')
        if report['immutableSourceStatus'] != 'PASS' or report['immutableOutputStatus'] != 'PASS' or report.get('inputError') or report.get('infrastructureError') or report.get('outputChanges'):
            raise ValueError(name + ': final source/output guards did not pass.')
        for snapshot in [report['source'], report['after']]:
            if snapshot['git']['head'] != EXPECTED or snapshot['git']['dirty']:
                raise ValueError(name + ': lane was not on the clean frozen commit.')
            for key in ['runtime', 'verification']:
                if snapshot[key] != freeze[key]: raise ValueError(name + ': frozen ' + key + ' differs.')
            if snapshot['offline'] != freeze['artifact']:
                raise ValueError(name + ': complete offline identity differs.')
        for row in report['tests']:
            if row['status'] == 'NOT RUN' or not row.get('processCompleted') or not row.get('actualProcess', {}).get('processCompleted'):
                raise ValueError(name + ': missing actual process close: ' + row['file'])
            for record in row['evidence']: check_seal(ROOT, record, 'path')
            stem = row['file'].replace('/', '_')
            completion = load(directory / (stem + '.completion.json'))
            if completion != row: raise ValueError('Completion differs from final report: ' + row['file'])
            actual = load(directory / (stem + '.process.json'))
            if actual != row['actualProcess']: raise ValueError('Actual process record differs: ' + row['file'])
            for suffix, kind in [('.results.jsonl', 'stdout'), ('.tap', 'stderr')]:
                data = add(directory / (stem + suffix))
                if len(data) != actual[kind + 'Bytes']:
                    raise ValueError('Actual process byte count differs: ' + row['file'])
                if kind + 'Sha256' in actual and sha(data) != actual[kind + 'Sha256']:
                    raise ValueError('Actual process capture hash differs: ' + row['file'])
            add(directory / (stem + '.completion.json'))
        for filename in ['report.json', 'inventory.json', 'run.mjs', 'capture-test.mjs']:
            add(directory / filename)
        for filename in ['baseline.json', 'freeze.json', 'actual-node-summary.json']:
            if (directory / filename).is_file(): add(directory / filename)
        lane_reports[name] = report
    handoff = load(BASE / 'archive-handoff-final.json')
    close = load(BASE / 'archive-handoff-final.process.json')
    if handoff['status'] != 'PASS' or handoff['summary'] != {'legacyStates': 14, 'passed': 16, 'failed': 0, 'publicCommands': 22} or not handoff['immutableSource']:
        raise ValueError('Final source-engine handoff is not the complete closed sixteen-case proof.')
    if close['terminal'] != {'code': 0, 'signal': None} or not close['primaryUnchanged']:
        raise ValueError('Handoff process did not close cleanly.')
    for snapshot in [handoff['before']['main'], handoff['after']['main']]:
        if snapshot['git'] != {'head': EXPECTED, 'dirty': False} or snapshot['runtime'] != freeze['runtime'] or snapshot['verification'] != freeze['verification']:
            raise ValueError('Handoff main identity differs from frozen release.')
    check_seal(ROOT, close['sourceReport'], 'path')
    for record in close['outputs'].values(): check_seal(BASE, record)
    add(BASE / 'archive-handoff-final.process.json')
    for record in handoff['fixtures']: check_seal(ROOT, record, 'path')
    build = load(BASE / 'build/report.json')
    if build['terminal'] != {'code': 0, 'signal': None} or not build['inputsUnchanged'] or build['before'] != build['after']:
        raise ValueError('Archive build did not close on unchanged inputs.')
    if build['before']['archiveHead'] != PINNED or build['before']['archiveStatus']:
        raise ValueError('Unexpected archive baseline.')
    for record in build['outputs'].values(): check_seal(BASE / 'build', record)
    check_seal(ROOT, build['manifest'], 'path')
    archive_manifest = build['manifest']['value']
    if load(ROOT / build['manifest']['path']) != archive_manifest:
        raise ValueError('Actual archive manifest differs from build report.')
    if archive_manifest['source']['commit'] != PINNED or archive_manifest['hosting']['bytes'] > archive_manifest['hosting']['limitBytes'] or archive_manifest['hosting']['limitBytes'] != 256 * 1024 * 1024:
        raise ValueError('Archive source/hosting bound differs.')
    if archive_manifest['storage'] != {'indexedDB': 'hearth-and-oath-legacy', 'keyPrefix': 'hearth-and-oath-legacy:'} or archive_manifest['artifact']['includedInHosting'] is not False or archive_manifest['offlineFileKind'] != 'same-origin-loader':
        raise ValueError('Archive storage/standalone isolation differs.')
    if sha(add('scripts/archive-compatibility.patch')) != archive_manifest['source']['overlay']['sha256'] or sha(add('scripts/build-archive.mjs')) != build['before']['builderSha256']:
        raise ValueError('Build source/overlay bytes differ.')
    for snapshot in [handoff['before']['archive'], handoff['after']['archive']]:
        if snapshot['runtime'] != archive_manifest['source']['runtime']:
            raise ValueError('Patched source used by handoff differs from built archive.')
    baseline_dir = ROOT / 'artifacts/old-rules-archive/baseline-tests'
    baseline = load(baseline_dir / 'report.json')
    if baseline['terminal'] != {'code': 0, 'signal': None} or not baseline['sourceUnchanged'] or baseline['counts'] != {'tests': 71, 'suites': 0, 'pass': 71, 'fail': 0, 'cancelled': 0, 'skipped': 0, 'todo': 0}:
        raise ValueError('Pinned, unpatched baseline proof differs.')
    if baseline['before']['head'] != PINNED or baseline['after']['head'] != PINNED:
        raise ValueError('Baseline tests used another commit.')
    for record in baseline['outputs'].values(): check_seal(baseline_dir, record)
    add(baseline_dir / 'report.json')
    add(BASE / 'build/report.json')
    add(BASE / 'freeze.json')
    for name in ['archive-preparation.json', 'main-preparation.json']: add(BASE / 'qa' / name)
    publication = load(BASE / 'archive-publication.json')
    observations = load(BASE / 'browser/observations.json')
    if publication['deploymentStatus'] != 'succeeded' or publication['audience'] != 'public' or publication['runtimeSha256'] != archive_manifest['source']['runtime']['sha256'] or publication['archiveStorage']['bytes'] > 256 * 1024 * 1024:
        raise ValueError('Native archive publication record differs from the built runtime/hosting bound.')
    if not observations['publicArchiveOpened'] or observations['archiveImport']['status'] != 'INTERRUPTED' or observations['archiveImport']['completeBrowserRoundTrip'] != 'NOT RUN' or observations['mainExport']['sha256'] != DOWNLOAD or not observations['mainExport']['wholeStateMatches']:
        raise ValueError('Actual browser observation scope or export binding differs.')
    add(BASE / 'archive-publication.json')
    add(BASE / 'browser/observations.json')
    browser_export = add(BASE / 'browser/main-browser-export.json')
    if sha(browser_export) != DOWNLOAD:
        raise ValueError('Actual browser export bytes differ from recorded whole-state download.')
    for name in ['dist/offline/manifest.json', 'dist/offline/recipe.json', 'scripts/verify-archive-handoff.mjs', 'tests/archive-link.test.js', 'dist/js/archive-link.js', 'artifacts/old-rules-archive/step71-reproduction.json', 'artifacts/archive-v0712/final-proofs/package.py']:
        add(name)
    for name in args.optional_file:
        file = Path(name)
        if file.is_absolute(): file = file.relative_to(ROOT)
        if not file.as_posix().startswith('artifacts/') or file.suffix not in ['.json', '.jsonl', '.log', '.md', '.jpg', '.png', '.mjs', '.py', '.tap'] or file.name.endswith('transport-live.log') or 'partial' in file.name:
            raise ValueError('Optional evidence must be an explicit closed, small artifacts/ file.')
        add(file)
    main_publication = None
    if 'artifacts/archive-v0712/main-publication.json' in args.optional_file:
        main_publication = load(BASE / 'main-publication.json')
        if main_publication['status'] != 'succeeded' or main_publication['audience'] != 'public' or main_publication['source_tree'] != freeze['tree'] or main_publication['runtimeSha256'] != freeze['runtime']['sha256']:
            raise ValueError('Main native publication does not bind the frozen source tree/runtime.')
    native = None
    native_selected = None
    if args.native_closed:
        native_dir = BASE / 'native'
        native_seals = load(native_dir / 'seals.json')
        native = load(native_dir / 'process.json')
        if not native_seals.get('closed') or not native.get('closedAt') or not native.get('immutableSourceAndArtifact'):
            raise ValueError('Single native checker is not closed with unchanged source/artifact.')
        for snapshot in [native['before'], native['after']]:
            if snapshot['primary'] != {'head': EXPECTED, 'status': ''} or snapshot['qa']['head'] != EXPECTED or snapshot['qa']['status'] or snapshot['qa']['runtime'] != freeze['runtime'] or snapshot['qa']['verification'] != freeze['verification'] or snapshot['qa']['artifact'] != freeze['artifact']:
                raise ValueError('Native checker did not use the exact frozen source/artifact.')
        for record in native_seals['files']: check_seal(native_dir, record, 'path')
        for record in native['outputs'].values(): check_seal(native_dir, record, 'path')
        add(native_dir / 'seals.json')
        selected_seals = load(native_dir / 'checker-result.seals.json')
        native_selected = load(native_dir / 'checker-result.json')
        if not selected_seals.get('closed') or native_selected['checkerExecutions'] != 1 or native_selected['terminal'] != native['terminal'] or native_selected['auxiliaryCapture']['status'] != native['status']:
            raise ValueError('Derived semantic result suppresses or disagrees with the closed original capture.')
        for record in selected_seals['files']: check_seal(native_dir, record, 'path')
        raw = (native_dir / 'stdout.log').read_text()
        decoder = json.JSONDecoder()
        first, boundary = decoder.raw_decode(raw)
        remainder = raw[boundary:].lstrip()
        second, end = decoder.raw_decode(remainder)
        if remainder[end:].strip() or first != native_selected['diagnostic'] or second != native_selected['semantic']:
            raise ValueError('Derived result does not consume the two complete original stdout documents.')
        if second['version'] != '0.71.2' or second['artifactSha256'] != freeze['artifact']['sha256'] or second['sessions'] != 1 or len(second['cases']) != 14:
            raise ValueError('Derived semantic scope differs from the one final checker.')
        add(native_dir / 'checker-result.seals.json')
        for name in ['prelaunch-guard-failure.json', 'prelaunch-repair.json', 'prelaunch-rejected-capture.mjs']:
            if (native_dir / name).is_file(): add(native_dir / name)
    counts = {key: sum(report['summary'][key] for report in lane_reports.values()) for key in ['passed', 'failed', 'skipped']}
    statuses = {'strictTestLanes': 'FAIL' if counts['failed'] or counts['skipped'] else 'PASS', 'sourceEngineHandoff': 'PASS', 'unpatchedArchiveBaseline': 'PASS', 'archiveBuild': 'PASS', 'publicArchivePublication': 'SUCCEEDED — native publication record', 'publicArchiveBrowserOpened': 'OBSERVED — actual Chrome', 'publicArchiveBrowserImport': 'INCOMPLETE — first attempt interrupted; second tool-reported timeout; no completed roundtrip', 'browserRoundtrip': 'NOT RUN', 'mainV0712Publication': 'SUCCEEDED — native publication record' if main_publication else 'NOT INCLUDED', 'humanFarmerPlaytest': 'NOT RUN', 'formalFullSoftwareGate': 'NOT CERTIFIED BY THIS PACKAGE'}
    statuses['targetedNativeOfflineChecker'] = native_selected['status'] if native_selected else 'NOT INCLUDED'
    statuses['nativeAuxiliaryCapture'] = native['status'] if native else 'NOT INCLUDED'
    statuses['fullThirtyOfflineCertification'] = False
    statuses['otherOfflineChecks'] = '29 NOT RUN' if native else 'NOT CERTIFIED BY THIS PACKAGE'
    pathmap = {'schemaVersion': 1, 'absoluteWorkspaceRoots': {str(ROOT): '.'}, 'rule': 'Strip the listed root; retain internal relative paths. External runtime/source references are not included.'}
    readme = f'''# Hearth & Oath v0.71.2 closed proof package\n\nFrozen source: {EXPECTED}.\nFAST: {lane_reports['fast']['summary']}.\nSLOW: {lane_reports['slow']['summary']}.\nFinal lane counts are taken once from closed reports; skips remain skips.\nBoth immutable source/output guards passed before packaging.\n\nThe source-engine handoff has 16 passing cases, 14 genuine Old Rules fixture\nstates and 22 public commands. It does not execute browser/storage/offline UI.\nThe separate 71/71 archive test record is the original unpatched baseline,\nnot an additional final-overlay suite. The built patched archive and the\nhandoff source are bound by the same runtime hash.\n\nThe pinned archive build records {archive_manifest['hosting']['bytes']} hosted\nbytes below its 256MiB limit. Only its small loader/manifest is hosted as the\nold-rules alias. Large standalone HTML, Site archives, source bundles, QA\nworktrees, artwork, music and offline parts are excluded here.\n\nThe owner reported public archive version 1 opened in actual Chrome (source\n43ee1a8b, tree 848a699, runtime f4d05cc7). The retained actual main v0.71.1/105\nslot export has complete-file SHA256 {DOWNLOAD}.\nThe public archive import attempt hung in Cua and the user interrupted it.\nThere was no completed browser roundtrip and no retry. Main v0.71.2 publication\nwas pending at preparation. Explicit optional records, if supplied, retain\ntheir own statuses; no success is inferred from their presence.\nSingle final native compiled startup checker: {native_selected['status'] if native_selected else 'NOT INCLUDED'}.
Original auxiliary capture-summary parser: {native['status'] if native else 'NOT INCLUDED'};
its complete original failure/seals remain unchanged. The selected semantic
result is parsed from both complete documents in the same closed stdout,
with all raw bytes consumed; no checker was re-executed.
Its raw semantic result and actual process/seals are retained when included.
A prior cleanliness guard stopped before spawn (zero checker executions);
its report and disposable residue-quarantine metadata remain separate.
The other 29 offline checks remain NOT RUN for this frozen snapshot.
Human farmer playtest: NOT RUN. The formal complete software gate is not\ncertified by this bundle. No v0.72 widening is authorized by these records.\n\nAll selected inputs were read stably and verified against their recorded\nseals where available. Live logs/partial checkpoints are excluded. Original\npaths are retained; see proof-path-map.json. Tar/gzip metadata is normalized;\ntwo independent builds and a full member readback must agree.\n'''
    for name, value in [('README.md', readme.encode()), ('proof-path-map.json', (json.dumps(pathmap, sort_keys=True, indent=2) + '\n').encode())]:
        files[name] = {'data': value, 'source': None, 'stamp': None}
    inventory = [{'path': name, 'bytes': len(row['data']), 'sha256': sha(row['data'])} for name, row in sorted(files.items())]
    files['proof-inventory.json'] = {'data': (json.dumps({'scope': 'Excludes this recursive inventory; the external manifest lists every member.', 'members': inventory}, sort_keys=True, indent=2) + '\n').encode(), 'source': None, 'stamp': None}
    inventory = [{'path': name, 'bytes': len(row['data']), 'sha256': sha(row['data'])} for name, row in sorted(files.items())]
    def build_tar(file):
        with file.open('wb') as raw:
            with gzip.GzipFile(filename='', mode='wb', fileobj=raw, compresslevel=9, mtime=0) as zipped:
                with tarfile.open(fileobj=zipped, mode='w|', format=tarfile.USTAR_FORMAT) as tar:
                    for name, row in sorted(files.items()):
                        info = tarfile.TarInfo(name); info.size = len(row['data']); info.mode = 0o644
                        info.uid = info.gid = info.mtime = 0; info.uname = info.gname = ''
                        tar.addfile(info, io.BytesIO(row['data']))
            raw.flush(); os.fsync(raw.fileno())
    first, second = ARCHIVE.with_suffix('.tmp'), ARCHIVE.with_suffix('.repeat.tmp')
    build_tar(first); build_tar(second); data = first.read_bytes()
    if data != second.read_bytes(): raise ValueError('Independent deterministic builds differ.')
    with tarfile.open(first, 'r:gz') as tar:
        if tar.getnames() != sorted(files): raise ValueError('Archive member list differs.')
        for member in tar:
            if not member.isfile() or member.mode != 0o644 or member.uid or member.gid or member.mtime or tar.extractfile(member).read() != files[member.name]['data']:
                raise ValueError('Archive readback differs: ' + member.name)
    for row in files.values():
        if row['source'] is not None and (stamp(row['source']) != row['stamp'] or row['source'].read_bytes() != row['data']):
            raise ValueError('Closed proof changed during packaging: ' + str(row['source']))
    first.replace(ARCHIVE); second.unlink()
    manifest = {'schemaVersion': 1, 'version': '0.71.2', 'archive': {'path': str(ARCHIVE.relative_to(ROOT)), 'bytes': len(data), 'sha256': sha(data), 'format': 'deterministic USTAR in gzip', 'gzipMtime': 0, 'memberMtime': 0, 'determinism': 'Two independent builds were byte-identical.', 'readback': 'Every member matched its selected input.'}, 'statuses': statuses, 'freeze': freeze, 'fast': lane_reports['fast']['summary'], 'slow': lane_reports['slow']['summary'], 'laneCaseTotals': counts, 'handoff': handoff['summary'], 'archiveBaseline': baseline['counts'], 'archiveBuild': archive_manifest, 'archivePublication': publication, 'browserObservations': observations, 'mainPublication': main_publication, 'nativeCapture': native, 'nativeChecker': native_selected, 'optionalFiles': args.optional_file, 'memberCount': len(inventory), 'uncompressedBytes': sum(row['bytes'] for row in inventory), 'pathMap': pathmap, 'members': inventory, 'limits': ['No active logs or partial checkpoints are packaged.', 'Unpatched baseline tests remain distinct from final-overlay source handoffs.', 'No browser roundtrip, native checker success or human verdict is invented.', 'Large game/media/source/Site/QA trees are excluded.']}
    MANIFEST.write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'archive': str(ARCHIVE), 'bytes': len(data), 'sha256': sha(data), 'manifest': str(MANIFEST), 'manifestSha256': sha(MANIFEST.read_bytes()), 'members': len(inventory), 'uncompressedBytes': manifest['uncompressedBytes'], 'statuses': statuses}))

if __name__ == '__main__': main()
