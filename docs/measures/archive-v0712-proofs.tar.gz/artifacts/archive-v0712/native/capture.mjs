import {spawn,execFileSync} from 'node:child_process';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {runtimeIdentity,verificationIdentity,validateOfflineIdentity} from '../../../scripts/lib/release-identity.mjs';
const dir=path.dirname(fileURLToPath(import.meta.url)),primary=path.resolve(dir,'../../..'),qa=primary+'/artifacts/archive-v0712/qa/main';
const hash=b=>createHash('sha256').update(b).digest('hex');
const git=(cwd,...args)=>execFileSync('git',args,{cwd,encoding:'utf8'}).trim();
const freeze=JSON.parse(await readFile(dir+'/freeze.json','utf8'));
async function snapshot(){return {primary:{head:git(primary,'rev-parse','HEAD'),status:git(primary,'status','--porcelain')},qa:{head:git(qa,'rev-parse','HEAD'),status:git(qa,'status','--porcelain'),runtime:await runtimeIdentity(qa),verification:await verificationIdentity(qa),artifact:await validateOfflineIdentity(qa)}};}
const before=await snapshot();
if(before.primary.head!==freeze.freeze.commit||before.primary.status||before.qa.head!==freeze.freeze.commit||before.qa.status||JSON.stringify(before.qa.runtime)!==JSON.stringify(freeze.runtime)||JSON.stringify(before.qa.verification)!==JSON.stringify(freeze.verification)||JSON.stringify(before.qa.artifact)!==JSON.stringify(freeze.artifact))throw Error('Prepared source/artifact differs from frozen final snapshot');
const command=[process.execPath,'--experimental-vm-modules','scripts/verify-offline-module-startup-v71.mjs'];
const stdout=[],stderr=[],started=new Date().toISOString(),start=Date.now();
const child=spawn(command[0],command.slice(1),{cwd:qa,stdio:['ignore','pipe','pipe']});
child.stdout.on('data',b=>stdout.push(b));child.stderr.on('data',b=>stderr.push(b));
const terminal=await new Promise(resolve=>{child.on('error',e=>resolve({error:e.message}));child.on('close',(code,signal)=>resolve({code,signal}));});
const closedAt=new Date().toISOString(),durationMs=Date.now()-start,out=Buffer.concat(stdout),err=Buffer.concat(stderr),after=await snapshot();
let semantic;try{semantic=JSON.parse(out.toString('utf8'));}catch(error){semantic={status:'FAIL',parseError:error.message};}
const unchanged=JSON.stringify(before)===JSON.stringify(after);
const result={schemaVersion:1,kind:'one-final-main-QA-exact-compiled-startup',status:terminal.code===0&&terminal.signal===null&&semantic.status==='PASS'&&unchanged?'PASS':'FAIL',command,cwd:qa,childPid:child.pid,started,closedAt,durationMs,terminal,before,after,immutableSourceAndArtifact:unchanged,semantic,scope:'Exactly one complete downloaded SourceTextModule semantic session. No other offline checker executed; no native browser roundtrip.',limits:['Semantic fake DOM, controlled fixtures and platform timers; not a native browser layout or human playtest.','Browser roundtrip remains NOT RUN.','The other 29 offline checks are NOT RUN for this final snapshot.'],outputs:{stdout:{path:'stdout.log',bytes:out.length,sha256:hash(out)},stderr:{path:'stderr.log',bytes:err.length,sha256:hash(err)},runner:{path:'capture.mjs',bytes:(await readFile(fileURLToPath(import.meta.url))).length,sha256:hash(await readFile(fileURLToPath(import.meta.url)))}}};
await writeFile(dir+'/stdout.log',out);await writeFile(dir+'/stderr.log',err);await writeFile(dir+'/process.json',JSON.stringify(result,null,2)+'\n');
const files=['freeze.json','main-preparation.json','capture.mjs','stdout.log','stderr.log','process.json'];const rows=[];for(const file of files){const bytes=await readFile(dir+'/'+file);rows.push({path:file,bytes:bytes.length,sha256:hash(bytes)});}
await writeFile(dir+'/seals.json',JSON.stringify({status:result.status,closed:true,files:rows},null,2)+'\n');console.log(JSON.stringify({status:result.status,terminal,durationMs,immutableSourceAndArtifact:unchanged,semantic,proofFiles:rows},null,2));if(result.status!=='PASS')process.exitCode=1;
