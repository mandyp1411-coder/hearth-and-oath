import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const dir=path.dirname(fileURLToPath(import.meta.url));
const hash=b=>createHash('sha256').update(b).digest('hex');
const originalSeals=JSON.parse(await readFile(dir+'/seals.json','utf8'));
for(const row of originalSeals.files){const bytes=await readFile(dir+'/'+row.path);assert.equal(bytes.length,row.bytes,row.path);assert.equal(hash(bytes),row.sha256,row.path);}
const raw=await readFile(dir+'/stdout.log'),newline=raw.indexOf(10);assert.ok(newline>0);
const diagnostic=JSON.parse(raw.subarray(0,newline).toString('utf8'));
const semantic=JSON.parse(raw.subarray(newline+1).toString('utf8'));
const processReport=JSON.parse(await readFile(dir+'/process.json','utf8'));
const freeze=JSON.parse(await readFile(dir+'/freeze.json','utf8'));
assert.equal(diagnostic.vmMode,'complete unchanged SourceTextModule');assert.equal(diagnostic.filename,'exact-full-module-v71.js');assert.equal(diagnostic.inertMedia,'native per-realm JSON parse');assert.match(diagnostic.codeSha256,/^[a-f0-9]{64}$/);
assert.equal(processReport.terminal.code,0);assert.equal(processReport.terminal.signal,null);assert.equal(processReport.immutableSourceAndArtifact,true);
assert.equal(processReport.status,'FAIL');assert.equal(processReport.semantic.status,'FAIL');assert.match(processReport.semantic.parseError,/Unexpected non-whitespace character after JSON/);
assert.equal(semantic.status,'PASS');assert.equal(semantic.mode,diagnostic.vmMode);assert.equal(semantic.version,freeze.freeze.version);assert.equal(semantic.artifactSha256,freeze.freeze.artifactSha256);assert.equal(semantic.sessions,1);assert.equal(semantic.cases.length,14);assert.equal(new Set(semantic.cases).size,14);
const report={schemaVersion:1,status:'PASS',kind:'selected-checker-result-derived-from-exact-closed-stdout',checkerExecutions:1,command:processReport.command,cwd:processReport.cwd,durationMs:processReport.durationMs,terminal:processReport.terminal,immutableSourceAndArtifact:true,diagnostic,semantic,auxiliaryCapture:{status:'FAIL',processReport:'process.json',reason:'The original capture wrapper required one JSON document; actual checker stdout contains one diagnostic JSON line followed by one complete result JSON document. Its original failure and seals remain unchanged.',originalError:processReport.semantic.parseError},prelaunch:{report:'prelaunch-guard-failure.json',checkerExecutions:0,repair:'prelaunch-repair.json'},derivation:{source:'derive-closed-result.mjs',method:'Verify all original closed output seals, parse the entire first line as one diagnostic JSON document, then the entire remaining stdout as one result JSON document; no bytes omitted or altered and no checker re-executed.'},limits:['Exactly one bounded semantic SourceTextModule/fake-DOM session, not a native browser or human lifetime playtest.','Browser roundtrip remains NOT RUN.','The other 29 offline checks remain NOT RUN.','The original auxiliary capture-summary failure remains FAIL.'],proofs:originalSeals.files};
await writeFile(dir+'/checker-result.json',JSON.stringify(report,null,2)+'\n');
const files=['freeze.json','main-preparation.json','capture.mjs','stdout.log','stderr.log','process.json','seals.json','prelaunch-rejected-capture.mjs','prelaunch-guard-failure.json','prelaunch-repair.json','derive-closed-result.mjs','checker-result.json'];
const rows=[];for(const file of files){const bytes=await readFile(dir+'/'+file);rows.push({path:file,bytes:bytes.length,sha256:hash(bytes)});}
await writeFile(dir+'/checker-result.seals.json',JSON.stringify({selectedCheckerStatus:'PASS',auxiliaryCaptureStatus:'FAIL',closed:true,files:rows},null,2)+'\n');console.log(JSON.stringify({selectedCheckerStatus:'PASS',auxiliaryCaptureStatus:'FAIL',checkerExecutions:1,durationMs:report.durationMs,caseCount:semantic.cases.length,artifactSha256:semantic.artifactSha256,report:rows.find(row=>row.path==='checker-result.json'),seals:'checker-result.seals.json'},null,2));
