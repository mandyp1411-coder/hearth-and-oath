# Hearth & Oath v0.71 evidence

This archive contains selected composite reports and their closed raw proofs.
FAST: 3198 passes, no failures, four skips. SLOW: 741 passes, no failures, one
skip. Both strict lane results remain FAIL because skipped cases remain skipped.
The offline composite has its own selected and original results; read it directly.
No formal full-software PASS or human farmer-playtest verdict is claimed.

The selected FAST and SLOW results are explicit composites with separate input
fingerprints. Original failures are preserved. The frozen four-life diagnostic
and benchmark concern mechanical snapshot A, not human participants. The build
log and strict content validation are the final B build.

Internal artifacts/... paths are preserved. For archived absolute proof paths,
strip either known workspace root listed in proof-path-map.json. Both aliases
map to this extraction root; collisions were accepted only for identical bytes.
Interpreters and source/test paths outside artifacts/ refer to the repository,
not files bundled here. Offline manifest/recipe data are records; the large
HTML, game parts, artwork, music, build and Site archives are deliberately absent.

Every member has normalized mode, owner and epoch timestamp. The gzip header
also uses epoch time and no original filename. The external proof-manifest JSON
records the archive SHA256 and a complete member inventory.
