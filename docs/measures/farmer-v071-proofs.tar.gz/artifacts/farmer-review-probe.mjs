import * as engine from '../dist/js/engine.js';
import { rollBirthCircumstances } from '../dist/js/station.js';
import { seasonOf } from '../dist/js/living-world.js';
import { writeFileSync } from 'node:fs';
const configs = [
 {seed:'farmer-review-common-village',station:'common',birthplace:'village'},
 {seed:'farmer-review-bound-village',station:'bound',birthplace:'village'},
 {seed:'farmer-review-common-forest',station:'common',birthplace:'forest'},
 {seed:'farmer-review-bound-brook',station:'bound',birthplace:'brook'},
];
const results=[];
function choose(s){
 const es=s.event, ids=es.choices.filter(c=>!c.disabledReason).map(c=>c.id), can=x=>ids.includes(x);
 const prefer=(...xs)=>xs.find(can);
 if(es.id==='farm_ambition')return prefer('keep','continue');
 if(es.id==='farm_sow')return prefer('beans','barley','fallow','continue');
 if(es.id==='farm_harvest')return s.farm.field.grain>=6?prefer('sell','split','store','continue'):prefer('split','store','sell','continue');
 if(es.id==='farm_due')return prefer('grain','pay','plead','continue');
 if(es.id==='farm_reckoning')return prefer('pay','neighbour','bond','continue');
 if(es.id==='farm_blight')return prefer('neighbour','ration','sell','continue');
 if(es.id==='farm_boundary')return prefer('witness','give','continue');
 if(es.id==='farm_boundary_turn')return prefer('confess','mend','continue');
 if(es.id==='farm_neighbour')return prefer('help','listen','continue');
 if(es.id==='farm_neighbour_reply')return prefer('accept','refuse','continue');
 if(es.id==='farm_spouse')return prefer('listen','continue');
 if(es.id==='farm_spouse_reply')return prefer('heard','keep','continue');
 if(es.id==='hard_winter')return prefer('endure');
 if(es.id==='debt_reckoning')return prefer('plead','bond','continue');
 if(es.id==='health_concern')return prefer('rest','support','continue');
 return prefer('continue','endure','rest','care','present','plead','private','wait','refuse','pause','leave','simplify')||ids[0];
}
for(const cfg of configs){
 let s=engine.createBirthGame({...cfg,difficulty:'gentle',station:rollBirthCircumstances(cfg.seed,cfg.station,'human'),appearance:{ancestry:'human'}});
 const r={...cfg,homeId:s.farm?.homeId,homeType:s.world.locations.find(p=>p.id===s.farm?.homeId)?.type,commands:0,events:{},actions:{},validChecks:0,errors:[],opening:null,final:null};
 let unchanged=0,last='', used=new Set();
 for(let guard=0;guard<1900&&s.phase!=='retired'&&s.age<31;guard++){
  let next, command;
  if(s.event){command=`event:${s.event.id}:${choose(s)}`;r.events[s.event.id]=(r.events[s.event.id]||0)+1;next=engine.chooseEventOption(s,choose(s));}
  else if(s.age<16){command=s.timeline.yearTarget!==null?'continueAgeUp':'ageUp';next=command==='ageUp'?engine.ageUp(s):engine.continueAgeUp(s);}
  else{
   r.opening??={age:s.age,day:s.day,gold:s.hero.gold,tenure:s.farm.tenure,location:s.locationId};
   const offers=engine.getActions(s).filter(a=>!a.disabledReason), season=seasonOf(s.day);
   let id=['farm_ambition','farm_sow','farm_plan','farm_talk_spouse','farm_talk_neighbour'].find(id=>offers.some(a=>a.id===id)&&!used.has(`${season}:${id}`));
   if(!id&&s.farm?.neighbourDebt>0&&s.hero.gold>80&&offers.some(a=>a.id==='farm_repay'))id='farm_repay';
   if(!id&&s.farm?.field.status!=='held'&&s.hero.gold>=100&&offers.some(a=>a.id==='farm_reclaim'))id='farm_reclaim';
   if(id){command=`action:${id}`;used.add(`${season}:${id}`);r.actions[id]=(r.actions[id]||0)+1;next=engine.chooseAction(s,id);}
   else{command=s.timeline.yearTarget!==null?'continueAgeUp':'liveSeason';next=command==='liveSeason'?engine.liveSeason(s):engine.continueAgeUp(s);}
  }
  r.commands++;r.validChecks++;
  if(!engine.validateSave(next)){r.errors.push({kind:'invalid',command,day:next.day,age:next.age,event:next.event?.id,notice:next.notice});s=next;break;}
  const sig=JSON.stringify([next.day,next.event,next.timeline.yearTarget,next.farm?.field,next.farm?.plan,next.farm?.ambition,next.farm?.lastTalk]);
  unchanged=sig===last?unchanged+1:0;last=sig;
  if(unchanged>=5){r.errors.push({kind:'stall',command,day:next.day,age:next.age,event:next.event?.id,notice:next.notice});s=next;break;}
  s=next;
 }
 r.final={age:s.age,day:s.day,phase:s.phase,location:s.locationId,gold:s.hero.gold,householdDebt:s.householdBudget?.debt,farmerDebt:s.farm?.neighbourDebt,field:s.farm?.field,harvests:s.farm?.harvests,wintersFed:s.farm?.wintersFed,ambition:s.farm?.ambition,neighbour:s.farm?.people?.neighbour&&{id:s.farm.people.neighbour.id,name:s.farm.people.neighbour.name,opinion:s.farm.people.neighbour.opinion},event:s.event?.id,notice:s.notice};
 if(s.age<31&&s.phase!=='retired'&&!r.errors.length)r.errors.push({kind:'guard',limit:1900});
 results.push(r);writeFileSync('artifacts/farmer-review-probe.json',JSON.stringify(results,null,2));console.log(JSON.stringify(r));
}
