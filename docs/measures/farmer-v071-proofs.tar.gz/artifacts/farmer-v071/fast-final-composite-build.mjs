// Read/copy audit only. No game or test source is edited or executed here.
import assert from 'node:assert/strict';
import { readFile, writeFile, stat, copyFile, mkdir } from 'node:fs/promises';
import { constants } from 'node:fs';
import path from 'node:path';
import { runtimeIdentity, verificationIdentity, gitIdentity, hashFile, sha256, validateOfflineIdentity, treeFiles, contentIdentity } from '../../scripts/lib/release-identity.mjs';
import { parseTestResults } from '../../scripts/lib/release-contract.mjs';

const currentRoot = '/workspace/scratch/68d171ec368e/hearth-and-oath';
const bRoot = '/workspace/scratch/68d171ec368e/hearth-cost-clarity';
const outputStem = path.join(currentRoot, 'artifacts/farmer-v071/fast-final-composite');
const proofRoot = outputStem + '.proofs';
const bReportPath = path.join(bRoot, 'artifacts/farmer-v071/robust-fast-b/report.json');
const bSummaryPath = path.join(bRoot, 'artifacts/farmer-v071/robust-fast-b/actual-node-summary.json');
const bInputsPath = path.join(bRoot, 'artifacts/farmer-v071/final-b/source-inputs.json');
const leafPath = path.join(currentRoot, 'artifacts/farmer-v071/creation-age-bound-recheck/report.json');
const target = 'tests/creation-qol-v58.test.js';
const correctedSha = '386b799a5c37603b1b0574bd922c50d78e7aa240a00e5b0324b80f1c023fac9f';
const readJSON = async file => JSON.parse(await readFile(file, 'utf8'));
const b = await readJSON(bReportPath), leaf = await readJSON(leafPath), bInputs = await readJSON(bInputsPath);
const snapshot = async () => ({ runtime: await runtimeIdentity(currentRoot), verification: await verificationIdentity(currentRoot), content: await contentIdentity(currentRoot, await treeFiles(currentRoot, 'content')), git: gitIdentity(currentRoot), offline: await validateOfflineIdentity(currentRoot) });
const before = await snapshot();
assert.deepEqual(before.runtime, b.source.runtime, 'current runtime bytes equal every retained B execution');
assert.deepEqual(before.content, b.source.content, 'authored content bytes equal B');
assert.equal(before.runtime.sha256, '43559063337c7bc243bc152ad153d672a9c933d61d85a494f17d3f46bddfa311');
assert.deepEqual(before.offline, b.source.offline, 'identical offline artifact and provenance');
assert.equal(b.immutableSourceStatus, 'PASS'); assert.equal(b.immutableOutputStatus, 'PASS');
assert.deepEqual(b.outputChanges, []); assert.deepEqual(b.byteDamagedProofCandidates, []);
assert.equal(leaf.status, 'PASS'); assert.equal(leaf.immutableSourceStatus, 'PASS'); assert.equal(leaf.immutableOutputStatus, 'PASS'); assert.deepEqual(leaf.outputChanges, []);
assert.deepEqual(leaf.before, leaf.after, 'the corrected complete-file recheck retained its own source fingerprint');
assert.deepEqual(leaf.before.runtime, before.runtime); assert.equal(leaf.before.testSha256, correctedSha);
assert.equal(await hashFile(path.join(currentRoot, target)), correctedSha);
assert.deepEqual(leaf.stats, { ...leaf.stats, passed: 20, failed: 0, skipped: 0, results: 20 });
assert.equal(leaf.actualProcess.code, 0); assert.equal(leaf.actualProcess.signal, null); assert.equal(leaf.actualProcess.error, null); assert.equal(leaf.actualProcess.processCompleted, true);

function metadata(info) { return { dev: info.dev, ino: info.ino, bytes: info.size, birthtimeMs: info.birthtimeMs, mtimeMs: info.mtimeMs, ctimeMs: info.ctimeMs }; }
async function seal(file) { const a = metadata(await stat(file)), digest = await hashFile(file), z = metadata(await stat(file)); assert.deepEqual(a, z, 'proof metadata stayed unchanged while hashing'); return { path: file, sha256: digest, metadata: z }; }
async function verifyRecorded(record, root) { const file = path.isAbsolute(record.path) ? record.path : path.join(root, record.path), actual = await seal(file); assert.equal(actual.sha256, record.sha256, 'sealed proof bytes: ' + file); assert.deepEqual(actual.metadata, record.metadata, 'sealed proof metadata: ' + file); return actual; }
const copies = [], seen = new Map();
async function preserve(file, destination) {
  if (seen.has(file)) return seen.get(file);
  await mkdir(path.dirname(destination), { recursive: true });
  const old = await seal(file); await copyFile(file, destination, constants.COPYFILE_EXCL); const copied = await seal(destination), after = await seal(file);
  assert.deepEqual(old, after, 'original proof is unchanged across copying'); assert.equal(copied.sha256, old.sha256, 'copied proof has exact original bytes');
  const item = { original: old, copied }; copies.push(item); seen.set(file, item); return item;
}
function tapSummary(text) {
  const m = text.match(/(?:^|\n)1\.\.(\d+)\n# tests (\d+)\n# suites (\d+)\n# pass (\d+)\n# fail (\d+)\n# cancelled (\d+)\n# skipped (\d+)\n# todo (\d+)\n# duration_ms ([0-9.]+)\s*$/);
  assert.ok(m, 'complete terminal TAP summary'); const keys = ['plan', 'tests', 'suites', 'passed', 'failed', 'cancelled', 'skipped', 'todo', 'durationMs'];
  const row = Object.fromEntries(keys.map((key, i) => [key, Number(m[i + 1])])); assert.equal(row.tests, row.passed + row.failed + row.cancelled + row.skipped + row.todo); return row;
}
const expectedRows = new Map(bInputs.rows.map(row => [row.file, row]));
const verificationChanges = [], unchangedTests = [];
for (const prior of bInputs.rows) {
  const file = path.join(currentRoot, prior.file), bytes = (await stat(file)).size, digest = await hashFile(file);
  if (digest !== prior.sha256 || bytes !== prior.bytes) verificationChanges.push({ file: prior.file, b: { bytes: prior.bytes, sha256: prior.sha256 }, current: { bytes, sha256: digest } });
  if (prior.file.startsWith('tests/')) {
    if (prior.file === target) assert.equal(digest, correctedSha);
    else { assert.equal(bytes, prior.bytes, 'unchanged test/helper/fixture bytes: ' + prior.file); assert.equal(digest, prior.sha256, 'unchanged test/helper/fixture hash: ' + prior.file); unchangedTests.push(prior.file); }
  }
}
assert.deepEqual(verificationChanges.map(row => row.file).sort(), ['scripts/verify-offline-module-startup-v71.mjs', target].sort(), 'only explicit corrected leaf checks differ from B verification input bytes');
const inventory = b.discovery.output; assert.equal(inventory, 'fast: 242 files\nslow: 36 files\n'); assert.equal(b.tests.length, 242);
const selected = [];
for (const row of b.tests) {
  const corrected = row.file === target, executed = corrected ? { ...row, ...leaf, passed: leaf.stats.passed, failed: leaf.stats.failed, skipped: leaf.stats.skipped, results: leaf.stats.results, code: leaf.actualProcess.code, signal: leaf.actualProcess.signal, error: leaf.actualProcess.error, actualProcess: leaf.actualProcess, processCompleted: true, tap: leaf.tap } : row;
  if (!corrected) { const prior = expectedRows.get(row.file); assert.ok(prior); assert.equal(await hashFile(path.join(currentRoot, row.file)), prior.sha256); }
  assert.equal(executed.processCompleted, true); assert.equal(executed.actualProcess.code, 0); assert.equal(executed.actualProcess.signal, null); assert.equal(executed.actualProcess.error, null); assert.equal(executed.failed, 0); assert.equal(executed.tap.failed, 0); assert.equal(executed.tap.cancelled, 0); assert.equal(executed.tap.todo, 0);
  const proofCopies = [];
  const records = corrected ? leaf.evidence : row.evidence;
  for (const record of records) {
    const verified = await verifyRecorded(record, corrected ? currentRoot : bRoot);
    proofCopies.push(await preserve(verified.path, path.join(proofRoot, corrected ? 'corrected-leaf' : 'retained-b', path.basename(verified.path))));
  }
  const tapFile = corrected ? path.join(currentRoot, leaf.evidence.find(item => item.path.endsWith('.tap')).path) : row.tapLog;
  const jsonlFile = corrected ? path.join(currentRoot, leaf.evidence.find(item => item.path.endsWith('.results.jsonl')).path) : row.resultsLog;
  const tapText = await readFile(tapFile, 'utf8'), jsonl = await readFile(jsonlFile, 'utf8'), parsed = parseTestResults(jsonl), tap = tapSummary(tapText);
  assert.deepEqual(tap, executed.tap); assert.equal(parsed.passed, executed.passed); assert.equal(parsed.failed, 0); assert.equal(parsed.skipped, executed.skipped); assert.equal(Buffer.byteLength(jsonl), executed.actualProcess.stdoutBytes); assert.equal(Buffer.byteLength(tapText), executed.actualProcess.stderrBytes);
  if (executed.actualProcess.stdoutSha256) assert.equal(sha256(jsonl), executed.actualProcess.stdoutSha256);
  if (executed.actualProcess.stderrSha256) assert.equal(sha256(tapText), executed.actualProcess.stderrSha256);
  selected.push({ file: row.file, provenance: corrected ? 'corrected full twenty-case PRIMARY recheck' : 'retained unchanged B file', status: tap.skipped ? 'FAIL' : 'PASS', node: tap, actualProcess: executed.actualProcess, sourceTestSha256: corrected ? correctedSha : expectedRows.get(row.file).sha256, proofCopies });
}
const originalFailure = b.tests.find(row => row.file === target); assert.equal(originalFailure.failed, 1);
const originalFailureProofs = [];
for (const record of originalFailure.evidence) { const verified = await verifyRecorded(record, bRoot); originalFailureProofs.push(await preserve(verified.path, path.join(proofRoot, 'original-b-failure', path.basename(verified.path)))); }
const runReports = [];
for (const [file, name] of [[bReportPath, 'original-b-report.json'], [bSummaryPath, 'original-b-summary.json'], [bInputsPath, 'original-b-inputs.json'], [leafPath, 'corrected-leaf-report.json']]) runReports.push(await preserve(file, path.join(proofRoot, name)));
const totals = Object.fromEntries(['tests', 'suites', 'passed', 'failed', 'cancelled', 'skipped', 'todo'].map(key => [key, selected.reduce((sum, row) => sum + row.node[key], 0)]));
assert.deepEqual(totals, { tests: 3202, suites: 0, passed: 3198, failed: 0, cancelled: 0, skipped: 4, todo: 0 });
const after = await snapshot(); assert.deepEqual(after, before, 'the current runtime/verification/content/HEAD/artifact snapshot remained unchanged during composition');
for (const item of copies) { assert.deepEqual(await seal(item.original.path), item.original); assert.deepEqual(await seal(item.copied.path), item.copied); }
const output = { schemaVersion: 1, assembledAt: new Date().toISOString(), status: 'FAIL', scope: 'Explicit composite of 241 retained B FAST files and one corrected full twenty-case PRIMARY test-file recheck; not one continuous full run of the changed verification tree.', runtimeCompatibility: 'PASS', sourceInputAudit: 'PASS', copiedProofAudit: 'PASS', actualNode: { files: selected.length, allSelectedActualProcessesExitedZero: true, ...totals }, strictResult: { status: 'FAIL', reason: 'Four optional cases were skipped and remain skipped; no formal full software PASS is claimed.', skippedFiles: selected.filter(row => row.node.skipped).map(row => ({ file: row.file, skipped: row.node.skipped })) }, provenance: { b: { runtime: b.source.runtime, verification: b.source.verification, git: b.source.git, offline: b.source.offline, originalStatus: b.status, originalSummary: b.summary }, correctedLeaf: { before: leaf.before, after: leaf.after, status: leaf.status, file: target, testSha256: correctedSha }, currentBefore: before, currentAfter: after, verificationChanges, unchangedOtherSelectedTestFiles: 241, unchangedTestHelperFixtureFiles: unchangedTests.length }, originalFailure: { file: target, actualNode: originalFailure.tap, failures: originalFailure.failures, evidence: originalFailureProofs, retained: true }, selectedTests: selected, reports: runReports, copies, limits: ['The historical B assertion failure is retained, not erased or relabelled.', 'The only selected replacement is the complete corrected CC06 test file; its other nineteen cases also passed.', 'The corrected native offline checker is a separately tracked verification change and is not covered by this FAST composite.', 'Four skips remain visible. Browser checks, offline checks, SLOW checks and human farmer playtest have separate evidence.'] };
await writeFile(outputStem + '.json', JSON.stringify(output, null, 2) + '\n', { flag: 'wx' });
await writeFile(outputStem + '.md', `# FAST final composite\n\n242 selected files: 241 retained unchanged B files plus the complete corrected twenty-case creator recheck. All selected actual Node processes exited zero. Actual Node totals: **3198 passed, 0 failed, 4 skipped**.\n\nStrict result: **FAIL**, solely because the four skipped optional cases remain skipped. This is an explicit composite with separate B, leaf and current fingerprints, not one continuous full run after the fixture changed.\n\nThe original B run remains 3197 passed, one CC06 assertion failure and four skips. Its report, complete failed-file proofs, and corrected full-file proofs are copied unchanged into fast-final-composite.proofs/. All 241 other selected test files, all other test/helper/fixture bytes, current runtime and authored content matched B. All original and copied sealed output hashes and metadata were revalidated.\n\nCurrent runtime: ${before.runtime.sha256}. B verification: ${b.source.verification.sha256}. Corrected leaf verification: ${leaf.before.verification.sha256}. Current verification: ${before.verification.sha256}.\n\nThe only verification byte changes from B are the corrected CC06 fixture and the separately corrected native offline checker. No production code, tests, or checkers were edited while composing this report.\n`, { flag: 'wx' });
console.log(JSON.stringify({ status: output.status, actualNode: output.actualNode, runtimeCompatibility: output.runtimeCompatibility, sourceInputAudit: output.sourceInputAudit, copiedProofAudit: output.copiedProofAudit, proofFiles: copies.length, report: outputStem + '.json', reportSha256: await hashFile(outputStem + '.json') }));
