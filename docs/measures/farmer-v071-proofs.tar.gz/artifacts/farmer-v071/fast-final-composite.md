# FAST final composite

242 selected files: 241 retained unchanged B files plus the complete corrected twenty-case creator recheck. All selected actual Node processes exited zero. Actual Node totals: **3198 passed, 0 failed, 4 skipped**.

Strict result: **FAIL**, solely because the four skipped optional cases remain skipped. This is an explicit composite with separate B, leaf and current fingerprints, not one continuous full run after the fixture changed.

The original B run remains 3197 passed, one CC06 assertion failure and four skips. Its report, complete failed-file proofs, and corrected full-file proofs are copied unchanged into fast-final-composite.proofs/. All 241 other selected test files, all other test/helper/fixture bytes, current runtime and authored content matched B. All original and copied sealed output hashes and metadata were revalidated.

Current runtime: 43559063337c7bc243bc152ad153d672a9c933d61d85a494f17d3f46bddfa311. B verification: e29573a844cc4197051f84b8e418c88f8ecf52e16d072d41048f93480d5a22f9. Corrected leaf verification: 853387ef85fd761f217ab5a86646f6fb1a832287a30bfebf21e2cad98fe8efc1. Current verification: d4b20442467f085b8b20a14cc1e854cc3d6171ef870f1c22c1ae0e1fa108b6ce.

The only verification byte changes from B are the corrected CC06 fixture and the separately corrected native offline checker. No production code, tests, or checkers were edited while composing this report.
