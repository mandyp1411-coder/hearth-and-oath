import { readFileSync, writeFileSync, copyFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { performance } from 'node:perf_hooks';
import { runtimeIdentity, verificationIdentity, gitIdentity, hashFile } from '../../scripts/lib/release-identity.mjs';

const root = process.cwd(), stem = 'artifacts/farmer-v071/frozen-farmer-diagnostic';
const expected = JSON.parse(readFileSync('artifacts/farmer-v071/lanes-start.json'));
const snapshot = async () => ({ runtime: await runtimeIdentity(root), verification: await verificationIdentity(root), git: gitIdentity(root) });
const before = await snapshot();
const matches = (a, b) => a.runtime.sha256 === b.runtime.sha256 && a.verification.sha256 === b.verification.sha256 && a.git.head === b.git.head;
if (!matches(before, expected)) throw Error('Diagnostic inputs differ from the final lane snapshot.');
const began = performance.now(), startedAt = new Date().toISOString(), script = 'artifacts/farmer-review-probe.mjs';
const scriptSha256 = await hashFile(script);
const run = spawnSync(process.execPath, [script], { cwd: root, encoding: 'utf8', timeout: 600000, maxBuffer: 10 * 1024 * 1024 });
writeFileSync(stem + '.log', (run.stdout || '') + (run.stderr || ''));
const after = await snapshot();
let lives = [];
try { lives = JSON.parse(readFileSync('artifacts/farmer-review-probe.json')); } catch {}
copyFileSync('artifacts/farmer-review-probe.json', stem + '.lives.json');
const report = {
  type: 'Mechanical public-engine diagnostic; no human participants or playtest verdict',
  startedAt, finishedAt: new Date().toISOString(), elapsedMs: performance.now() - began,
  node: process.version, platform: process.platform, script, scriptSha256,
  expectedSnapshot: 'artifacts/farmer-v071/lanes-start.json', before, after,
  immutableSource: matches(before, after) && matches(after, expected),
  process: { status: run.status, signal: run.signal, error: run.error?.message || null },
  commands: lives.reduce((n, r) => n + r.commands, 0), validatedTransitions: lives.reduce((n, r) => n + r.validChecks, 0),
  lives: lives.map(r => ({ seed: r.seed, station: r.station, homeId: r.homeId, homeType: r.homeType, commands: r.commands, errors: r.errors, final: r.final })),
};
report.passed = report.immutableSource && run.status === 0 && lives.length === 4 && lives.every(r => !r.errors.length && r.final.age === 31);
writeFileSync(stem + '.json', JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
process.exitCode = report.passed ? 0 : 1;
