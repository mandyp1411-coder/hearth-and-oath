All 30 selected offline checks pass on final v0.71 artifact B. This is an explicit composite: 29 terminal passes from the unchanged B run plus one corrected native leaf on exactly the same game, helper and artifact bytes. The original B run remains 29 PASS / 1 FAIL; it is not relabelled as a formal all-30 pass.

The extended native fixture had reopened the Book workspace, then tried a Day-only play. Its correction uses the ordinary Day control and asserts that navigation changes no saved state. It then verifies the actual compiled card shows a 3-gold fee and about 1 gold of household keep, and the public/actual command both advance three days and change 100 gold to 96. Ambition, Book reading, exact export, all three complete saves/backups, module privacy, native JSON parsing and zero network checks remain. The corrected leaf passed in 17.381 seconds.

Runtime: 43559063337c7bc243bc152ad153d672a9c933d61d85a494f17d3f46bddfa311

Artifact: 2884cbaac99290b8093852515930ca0f587543113d9e7b2c1aaa3a18887c10a6 (333654873 bytes; 40 parts)

Engine: d8526974420a515bfb3c78a91d9efe515780d4fad0a66d4b48b8d09dab0b8813

Shared helper: 97c7c6f35a29d2cdf6da6e5ab7f2a6a6639b9f9b0f2c252988193c022777e5a8

The machine-readable companion binds every selected checker and log to its SHA256 and records both changed leaf files (native navigation and the separately tested creation/QoL fixture). It seals every raw log and source manifest.

Seventeen older repeated-session checks share only an exact immutable inert asset table; native JSON.parse is restored before app startup. Three single legacy probes keep native asset parsing; ten complete-module checks keep actual module scope and native parsing. These are controlled semantic tests, not human playtest or physical-device certification.
