import {readdir,writeFile,readFile,access,stat} from 'node:fs/promises';
import {createWriteStream} from 'node:fs';
import {spawn,execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
import {runtimeIdentity,verificationIdentity,validateOfflineIdentity,hashFile} from '../../../scripts/lib/release-identity.mjs';
const root=fileURLToPath(new URL('../../../',import.meta.url)),out=fileURLToPath(new URL('.',import.meta.url));
const expectedHead='f8637926c2db25070435b50cb12311ef82d1afcd';
const head=()=>execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim();
const snapshot=async()=>({head:head(),runtime:await runtimeIdentity(root),verification:await verificationIdentity(root),offline:await validateOfflineIdentity(root)});
const initial=await snapshot();assert.equal(initial.head,expectedHead);
const baseline=JSON.parse(await readFile(root+'artifacts/farmer-v071/final-b/source-inputs.json','utf8'));
for(const key of ['runtime','verification','offline'])assert.deepEqual(initial[key],baseline[key],'runner matches frozen final B '+key);
const assertInput=s=>assert.deepEqual(s,initial,'all source, checker, fixture, artifact inputs and HEAD remain fixed');
const found=(await readdir(root+'/scripts')).filter(x=>/^verify-offline.*\.mjs$/.test(x)).sort();
const priority=['verify-offline-module-startup-v71.mjs','verify-offline-creation-qol-v580.mjs','verify-offline-interface-v40.mjs','verify-offline-feedback-v35.mjs'],scripts=[...priority,...found.filter(x=>!priority.includes(x))];
const summary={startedAt:new Date().toISOString(),head:expectedHead,command:['node','--max-old-space-size=2048','--expose-gc','<script>'],timeoutMs:900000,initial,scripts,checks:[],status:'running'};
await writeFile(out+'summary.json',JSON.stringify(summary,null,2)+'\n');
for(const script of scripts){
  try{await access(out+'stop-requested');summary.status='stopped-requested';break;}catch{}
  const started=Date.now(),entry={script:'scripts/'+script,startedAt:new Date().toISOString(),log:script.replace(/\.mjs$/,'.log'),timeout:false};
  assertInput(await snapshot());console.log('START '+script);
  const log=createWriteStream(out+entry.log);
  const child=spawn(process.execPath,['--max-old-space-size=2048','--expose-gc','scripts/'+script],{cwd:root,detached:true,stdio:['ignore','pipe','pipe']});
  child.stdout.pipe(log,{end:false});child.stderr.pipe(log,{end:false});
  let kill;
  const timer=setTimeout(()=>{entry.timeout=true;try{process.kill(-child.pid,'SIGTERM');}catch{}kill=setTimeout(()=>{try{process.kill(-child.pid,'SIGKILL');}catch{}},10000);},900000);
  const result=await new Promise(resolve=>{child.on('error',e=>resolve({code:null,signal:null,error:String(e)}));child.on('close',(code,signal)=>resolve({code,signal}));});
  clearTimeout(timer);if(kill)clearTimeout(kill);await new Promise(resolve=>log.end(resolve));
  entry.logSha256=await hashFile(out+entry.log);entry.logBytes=(await stat(out+entry.log)).size;
  Object.assign(entry,result,{durationMs:Date.now()-started,endedAt:new Date().toISOString(),status:result.code===0&&!entry.timeout?'pass':'fail'});
  try{assertInput(await snapshot());entry.inputsUnchanged=true;}catch(e){entry.inputsUnchanged=false;entry.inputError=String(e);summary.status='stopped-input-changed';}
  summary.checks.push(entry);await writeFile(out+'summary.json',JSON.stringify(summary,null,2)+'\n');
  console.log('END '+script+' '+entry.status+' '+entry.durationMs+'ms code='+result.code+' signal='+result.signal);
  if(entry.inputsUnchanged===false)break;
}
summary.endedAt=new Date().toISOString();summary.passed=summary.checks.filter(x=>x.status==='pass').length;summary.failed=summary.checks.filter(x=>x.status==='fail').length;
if(summary.status==='running')summary.status=summary.failed?'failed':'passed';summary.final=await snapshot();summary.gitStatus=execFileSync('git',['status','--short'],{cwd:root,encoding:'utf8'});
await writeFile(out+'summary.json',JSON.stringify(summary,null,2)+'\n');console.log(JSON.stringify({status:summary.status,passed:summary.passed,failed:summary.failed,executed:summary.checks.length,discovered:scripts.length}));
process.exitCode=summary.status==='passed'?0:1;
