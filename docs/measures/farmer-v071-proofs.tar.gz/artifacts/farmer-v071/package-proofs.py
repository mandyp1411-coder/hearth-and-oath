"""Package closed v0.71 evidence only; no game/source/checker mutation."""
from __future__ import annotations
import argparse, gzip, hashlib, io, json, os, tarfile, tempfile
from pathlib import Path

P = Path('/workspace/scratch/68d171ec368e/hearth-and-oath')
B = Path('/workspace/scratch/68d171ec368e/hearth-cost-clarity')
DEST = P / 'docs/measures/farmer-v071-proofs.tar.gz'
MANIFEST = P / 'docs/measures/farmer-v071-proof-manifest.json'
ROOT_MAP = {str(P): '.', str(B): '.'}
sha = lambda data: hashlib.sha256(data).hexdigest()

def read_json(p):
    return json.loads(p.read_text())

def stamp(p):
    s = p.stat()
    return (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)

def stable_bytes(p):
    if p.is_symlink() or not p.is_file():
        raise ValueError(f'Only regular proof files are accepted: {p}')
    before = stamp(p)
    data = p.read_bytes()
    if stamp(p) != before:
        raise ValueError(f'Proof file changed while reading: {p}')
    return data, before

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--closed-offline-handoff', action='store_true', required=True)
    parser.parse_args()
    fast = read_json(P/'artifacts/farmer-v071/fast-final-composite.json')
    slow = read_json(P/'artifacts/farmer-v071/slow-composite.json')
    offline = read_json(P/'artifacts/farmer-v071/offline-composite-b.json')
    if fast['actualNode']['passed'] != 3198 or fast['actualNode']['failed'] != 0 or fast['actualNode']['skipped'] != 4 or fast['status'] != 'FAIL':
        raise ValueError('Unexpected FAST composite; retain all four skips.')
    if slow['summary']['passed'] != 741 or slow['summary']['failed'] != 0 or slow['summary']['skipped'] != 1 or slow['status'] != 'FAIL':
        raise ValueError('Unexpected SLOW composite; retain its skip.')
    if offline['status'] != 'COMPOSITE PASS' or offline['selectedPass'] != 30 or offline['selectedFail'] != 0 or offline['formalSingleImmutableRun'] is not False:
        raise ValueError('Unexpected selected offline composite or scope.')
    original_offline = read_json(P/'artifacts/farmer-v071/offline-final-b/summary.json')
    native_offline = read_json(P/'artifacts/farmer-v071/offline-native-b-recheck/summary.json')
    if not original_offline.get('endedAt') or len(original_offline['checks']) != 30 or original_offline['passed'] != 29 or original_offline['failed'] != 1:
        raise ValueError('The original thirty-check B run has not closed as expected.')
    for row in original_offline['checks']:
        if not row.get('endedAt') or row['status'] not in ['pass','fail'] or row.get('timeout') or row.get('signal') or row.get('inputsUnchanged') is not True:
            raise ValueError('An original B checker is unfinished, interrupted or mixed-input.')
        raw_log = P/'artifacts/farmer-v071/offline-final-b'/row['log']
        if raw_log.stat().st_size != row['logBytes'] or sha(raw_log.read_bytes()) != row['logSha256']:
            raise ValueError('An original B closed log differs from its seal.')
    if not native_offline.get('endedAt') or native_offline['status'] != 'pass' or native_offline['code'] != 0 or native_offline.get('signal') or native_offline.get('timeout') or native_offline.get('inputsUnchanged') is not True:
        raise ValueError('The corrected native checker is not closed and passing.')
    for record in offline['rawProofSeals']:
        raw = P/record['file']
        if raw.stat().st_size != record['bytes'] or sha(raw.read_bytes()) != record['sha256']:
            raise ValueError(f'Offline raw proof differs from its final seal: {raw}')
    files = {}
    allowed = {'.json', '.jsonl', '.log', '.tap', '.mjs', '.md', '.py'}
    def add(root, relative, directory=False):
        source = root/relative
        if directory:
            if not source.is_dir():
                raise FileNotFoundError(source)
            for item in sorted(source.rglob('*')):
                if item.is_file():
                    if item.suffix not in allowed:
                        raise ValueError(f'Unexpected non-proof file in closed proof directory: {item}')
                    add(root, item.relative_to(root).as_posix())
            return
        data, metadata = stable_bytes(source)
        arcname = Path(relative).as_posix()
        if arcname.startswith('/') or '..' in Path(arcname).parts:
            raise ValueError(f'Unsafe archive path: {arcname}')
        if len(data) > 25*1024*1024:
            raise ValueError(f'Exclude large build/media artifacts: {source}')
        prior = files.get(arcname)
        origin = {'workspace': root.name, 'path': str(source)}
        if prior:
            if prior['data'] != data:
                raise ValueError(f'Root-alias collision with different proof bytes: {arcname}')
            prior['origins'].append(origin)
            prior['sources'].append((source, metadata))
        else:
            files[arcname] = {'data': data, 'origins': [origin], 'sources': [(source, metadata)]}
    for relative in [
        'artifacts/farmer-v071/fast-final-composite.json',
        'artifacts/farmer-v071/fast-final-composite.md',
        'artifacts/farmer-v071/slow-composite.json',
        'artifacts/farmer-v071/slow-composite.md',
        'artifacts/farmer-v071/offline-composite-b.json',
        'artifacts/farmer-v071/offline-composite-b.md',
        'artifacts/farmer-v071/lanes-start.json',
        'artifacts/farmer-v071/benchmark-final.log',
        'artifacts/farmer-v071/voice-cost-final.log',
        'artifacts/farmer-v071/frozen-farmer-diagnostic.json',
        'artifacts/farmer-v071/frozen-farmer-diagnostic.lives.json',
        'artifacts/farmer-v071/frozen-farmer-diagnostic.mjs',
        'artifacts/farmer-review-probe.mjs',
        'artifacts/farmer-v071/fast-final-composite-build.mjs',
        'artifacts/farmer-v071/package-proofs.py',
        'artifacts/farmer-v071/robust-fast-b/run.mjs',
        'artifacts/farmer-v071/robust-fast-b/capture-test.mjs',
        'artifacts/farmer-v071/robust-fast-b/README.md',
        'artifacts/farmer-v071/offline-harness-final.patch',
        'artifacts/farmer-v071/offline-harness-final-files.json',
    ]:
        add(P, relative)
    for relative in [
        'artifacts/farmer-v071/fast-final-composite.proofs',
        'artifacts/farmer-v071/robust-slow',
        'artifacts/farmer-v071/slow-b-recheck',
        'artifacts/farmer-v071/creation-age-bound-recheck',
        'artifacts/farmer-v071/offline-native-b-recheck',
        'artifacts/farmer-v071/offline-final-b',
    ]:
        add(P, relative, directory=True)
    for relative in [
        'artifacts/farmer-v071/robust-fast-b',
        'artifacts/farmer-v071/offline-final-b',
    ]:
        add(B, relative, directory=True)
    for relative in [
        'artifacts/farmer-v071/final-b/build.log',
        'artifacts/farmer-v071/final-b/source-inputs.json',
        'artifacts/content-validation/report.json',
        'artifacts/content-validation/report.md',
        'dist/offline/manifest.json',
        'dist/offline/recipe.json',
    ]:
        add(B, relative)
    for record in offline['rawProofSeals']:
        add(P, record['file'])
    readme = '''# Hearth & Oath v0.71 evidence\n\nThis archive contains selected composite reports and their closed raw proofs.\nFAST: 3198 passes, no failures, four skips. SLOW: 741 passes, no failures, one\nskip. Both strict lane results remain FAIL because skipped cases remain skipped.\nThe offline composite has its own selected and original results; read it directly.\nNo formal full-software PASS or human farmer-playtest verdict is claimed.\n\nThe selected FAST and SLOW results are explicit composites with separate input\nfingerprints. Original failures are preserved. The frozen four-life diagnostic\nand benchmark concern mechanical snapshot A, not human participants. The build\nlog and strict content validation are the final B build.\n\nInternal artifacts/... paths are preserved. For archived absolute proof paths,\nstrip either known workspace root listed in proof-path-map.json. Both aliases\nmap to this extraction root; collisions were accepted only for identical bytes.\nInterpreters and source/test paths outside artifacts/ refer to the repository,\nnot files bundled here. Offline manifest/recipe data are records; the large\nHTML, game parts, artwork, music, build and Site archives are deliberately absent.\n\nEvery member has normalized mode, owner and epoch timestamp. The gzip header\nalso uses epoch time and no original filename. The external proof-manifest JSON\nrecords the archive SHA256 and a complete member inventory.\n'''.encode()
    files['README.md'] = {'data': readme, 'origins': [], 'sources': []}
    path_map = {'schemaVersion': 1, 'absoluteWorkspaceRoots': ROOT_MAP, 'rule': 'Strip exactly one listed absolute workspace root; retain the remaining artifacts/... path.', 'collisionPolicy': 'Identical archived bytes required for every alias collision.'}
    files['proof-path-map.json'] = {'data': (json.dumps(path_map, sort_keys=True, indent=2)+'\n').encode(), 'origins': [], 'sources': []}
    index = [{'path': name, 'bytes': len(row['data']), 'sha256': sha(row['data']), 'origins': row['origins']} for name,row in sorted(files.items())]
    files['proof-inventory.json'] = {'data': (json.dumps({'schemaVersion': 1, 'scope': 'Evidence members and deterministic helper documents; this inventory excludes its own recursive hash.', 'members': index}, sort_keys=True, indent=2)+'\n').encode(), 'origins': [], 'sources': []}
    inventory = [{'path': name, 'bytes': len(row['data']), 'sha256': sha(row['data'])} for name,row in sorted(files.items())]
    DEST.parent.mkdir(parents=True, exist_ok=True)
    def build(destination):
        with destination.open('wb') as raw:
            with gzip.GzipFile(filename='', mode='wb', compresslevel=9, fileobj=raw, mtime=0) as zipped:
                with tarfile.open(fileobj=zipped, mode='w|', format=tarfile.USTAR_FORMAT) as archive:
                    for name,row in sorted(files.items()):
                        info = tarfile.TarInfo(name)
                        info.size=len(row['data']);info.mode=0o644;info.uid=0;info.gid=0;info.uname='';info.gname='';info.mtime=0
                        archive.addfile(info,io.BytesIO(row['data']))
            raw.flush();os.fsync(raw.fileno())
    first = DEST.with_name(DEST.name+'.tmp')
    second = DEST.with_name(DEST.name+'.repeat.tmp')
    build(first);build(second)
    first_bytes = first.read_bytes()
    if first_bytes != second.read_bytes():
        raise AssertionError('Repeated deterministic builds differ.')
    with tarfile.open(first,'r:gz') as archive:
        actual=archive.getmembers()
        if [m.name for m in actual] != sorted(files):
            raise AssertionError('Archive inventory differs.')
        for member in actual:
            if member.mtime != 0 or member.uid != 0 or member.gid != 0 or member.mode != 0o644 or not member.isfile():
                raise AssertionError('Archive metadata was not normalized.')
            if archive.extractfile(member).read() != files[member.name]['data']:
                raise AssertionError(f'Archived proof byte mismatch: {member.name}')
    for row in files.values():
        for source, metadata in row['sources']:
            if stamp(source) != metadata or sha(source.read_bytes()) != sha(row['data']):
                raise AssertionError(f'Selected closed proof changed while packaging: {source}')
    first.replace(DEST);second.unlink()
    manifest={'schemaVersion':1,'release':'0.71.0','archive':{'path':'docs/measures/'+DEST.name,'bytes':len(first_bytes),'sha256':sha(first_bytes),'format':'deterministic USTAR in gzip','gzipMtime':0,'normalizedMemberMtime':0,'determinismCheck':'Two independent builds were byte-identical.','memberReadback':'Every member was read back and matched its input bytes.'},'status':{'strictCompositeStatus':'FAIL','formalSingleSnapshotGate':'NOT RUN','reason':'FAST retains four skips and SLOW retains one; no strict full PASS is claimed. Human farmer playtest remains NOT RUN.','fast':fast['actualNode'],'slow':slow['summary'],'offlineCompositeStatus':offline.get('status'),'offlineSelectedPass':offline['selectedPass'],'offlineSelectedFail':offline['selectedFail'],'offlineFormalSingleImmutableRun':False},'absoluteWorkspaceRoots':ROOT_MAP,'evidenceFileCount':len(inventory),'uncompressedBytes':sum(r['bytes'] for r in inventory),'members':inventory,'limits':['Explicit composite inputs and preserved historical failures must be read in the individual reports.','The benchmark and four-life diagnostic concern mechanical A; build and strict content reports concern final B.','Large HTML/media/game parts/build and Site archives are excluded.','No active logs were selected.']}
    MANIFEST.write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'archive':str(DEST),'bytes':len(first_bytes),'sha256':sha(first_bytes),'files':len(inventory),'uncompressedBytes':manifest['uncompressedBytes'],'manifest':str(MANIFEST),'manifestSha256':sha(MANIFEST.read_bytes())}))

if __name__=='__main__':
    main()
