# Final UI B FAST evidence

Prepared only; no B lane starts until the owner agent confirms the final B
runtime, all checker/helper/test files, and matching offline build are frozen.
Everything here is disposable verification infrastructure under `artifacts/`.
It does not edit production source, tests, scripts or HEAD in either checkout.

The runner reads B's own `scripts/test-lanes.mjs`, derives its complete FAST
inventory and cross-checks the official `list` output. It accepts the new cost
test naturally (currently expected 242 files), runs four workers with one Node
test process per file, and keeps every skip visible. A skip blocks strict PASS.

Both reporters stay in memory until the actual Node child emits `close`.
Completion metadata records the real process status, byte lengths and hashes;
JSONL and TAP then have to agree with complete terminal totals. Persisted proof
files are checked against captured bytes and sealed again after all workers.
Runtime, verification inputs, source content, HEAD, built artifact and runner
infrastructure are compared before and after. There are no suppressed failures.

After final B freeze/build, capture its baseline once:

```sh
node /workspace/scratch/68d171ec368e/hearth-and-oath/artifacts/farmer-v071/robust-fast-b/run.mjs --root /workspace/scratch/68d171ec368e/hearth-cost-clarity --capture-baseline
```

Then run the complete lane, retaining the PTY session and redirecting only its
progress output to a new artifact file if desired:

```sh
node /workspace/scratch/68d171ec368e/hearth-and-oath/artifacts/farmer-v071/robust-fast-b/run.mjs --root /workspace/scratch/68d171ec368e/hearth-cost-clarity
```

The default output and baseline are in B's
`artifacts/farmer-v071/robust-fast-b/`. `--out`, `--baseline` and
`--expected-head` are available for explicit reviewable alternatives. Existing
evidence is never overwritten. A `STOP` file requests a clean boundary; running
children are stopped by SIGINT/SIGTERM and unfinished work remains NOT RUN.

Any byte-damaged output keeps the aggregate FAIL and identifies eligible proof
repair candidates. Reruns must use fresh paths and unchanged input identities;
only damaged proofs may be repaired. An observed gameplay assertion failure is
never turned into a pass by this mechanism.

The capture protocol's tiny smoke fixture passed: nested result totals, exact
post-close byte hashes, and a deliberately skipped case that stayed visible and
blocked strict PASS. This smoke is not counted as a game or release test.
