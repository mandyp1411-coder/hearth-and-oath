# v0.71 SLOW evidence composite

This combines 34 unchanged test files executed in frozen A with complete replays of the two repaired fixture files in frozen B. It is **not one full immutable B SLOW run**. Both snapshots and the five original failures are retained in the JSON report. The engine SHA-256 is unchanged: d8526974420a515bfb3c78a91d9efe515780d4fad0a66d4b48b8d09dab0b8813.

Selected actual Node results: **741 passed, 0 failed, 1 skipped** across all 36 official SLOW files. All selected Node file processes exited zero. Strict aggregate: **FAIL**, because the unshipped reference-art test remains skipped.

All 152 retained A/B output byte hashes and sizes were rechecked. All 34 retained test file byte hashes match A. The B runtime, verification inputs and offline identity remain unchanged after its two-file replay.

- tests/rpg-v18.test.js: all 384 enemy cells are real registered illustrations with truthful species bindings — reference-art/ is not present in this checkout
