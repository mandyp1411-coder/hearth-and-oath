# Hearth & Oath v0.71.1 closed proofs

Frozen source: c369b934cb8a1abeeed04ee69b6db39bf7e32ee1.
FAST: 3206 passed, 0 failed, 4 skipped.
SLOW: 741 passed, 0 failed, 1 skipped.
Skips remain skips and prevent strict test-lane PASS. The formal complete
software gate was not run/certified: targeted offline run B passed four checks;
the other twenty-six remain NOT RUN. No human farmer-playtest verdict is claimed.

Original offline run A and its AUXILIARY SEAL FAIL are preserved separately.
Its semantic passes are not promoted as clean selected proof. Run B is the
selected immutable four-check run and uses the declared native/legacy scope.
Memory statistics are Linux wait4 per-process high-water data, not aggregate
subtree RSS. See the raw offline report for the precise limits.

opening-final/ and annual-contribution-final/ are pre-C3 preflights with their
own dirty 8af7... HEAD and verification fingerprints. They are not the clean
c369... lane run and their cases are not added again to FAST/SLOW totals.
Both old age-16 opening fixtures consumed by the new FAST test are supplied at
their exact C3 Git blobs, with independent SHA256/byte bindings in the manifest.
This supplies consumed inputs; it is not an additional gameplay test.

Internal artifacts/... paths are preserved. Strip the primary absolute root
listed in proof-path-map.json when resolving archived proof paths. The large
HTML/game parts, artwork/music, source tar and Site archive are omitted. The
small actual browser JPEGs and their JSON measurements are included. Manifest
and recipe files are build records, not the full executable download.

Only closed, hash-checked per-file assertion outputs and their final guards are
selected for the lanes. Progress and transport-live append logs are excluded.
Tar owners, permissions and timestamps are normalized; gzip uses epoch time
and no original filename. All members are read back after deterministic builds.
