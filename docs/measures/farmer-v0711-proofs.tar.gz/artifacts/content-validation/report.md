# Content validation

Schema 1; tree `content`; 2026-10-24.

| Files | Items | Text fields | Errors | Warnings | Voice hits |
| --- | --- | --- | --- | --- | --- |
| 15 | 50 | 4343 | 0 | 0 | 0 |

## By kind

| Kind | Files | Items |
| --- | --- | --- |
| scene | 2 | 24 |
| thread | 1 | 2 |
| foe | 1 | 2 |
| place | 1 | 1 |
| landmark | 1 | 1 |
| ambition | 2 | 7 |
| play | 1 | 1 |
| dialogue | 2 | 3 |
| design-asset | 4 | 9 |

## By file

| File | Kind | Items | Text fields | Errors | Warnings | Voice hits |
| --- | --- | --- | --- | --- | --- | --- |
| content/examples/ambition.json | ambition | 1 | 6 | 0 | 0 | 0 |
| content/examples/design-asset.json | design-asset | 1 | 8 | 0 | 0 | 0 |
| content/examples/dialogue.json | dialogue | 1 | 13 | 0 | 0 | 0 |
| content/examples/foe.json | foe | 2 | 33 | 0 | 0 | 0 |
| content/examples/landmark.json | landmark | 1 | 5 | 0 | 0 | 0 |
| content/examples/place.json | place | 1 | 9 | 0 | 0 | 0 |
| content/examples/play.json | play | 1 | 15 | 0 | 0 | 0 |
| content/examples/scene.json | scene | 4 | 46 | 0 | 0 | 0 |
| content/examples/thread.json | thread | 2 | 0 | 0 | 0 | 0 |
| content/expansion-v27/encounter_design_v27.json | design-asset | 1 | 2269 | 0 | 0 | 0 |
| content/expansion-v27/personal_stories_v27.json | design-asset | 1 | 750 | 0 | 0 | 0 |
| content/expansion-v27/regional_stories_v27.json | design-asset | 6 | 864 | 0 | 0 | 0 |
| content/farmer/ambitions.json | ambition | 6 | 12 | 0 | 0 | 0 |
| content/farmer/dialogue.json | dialogue | 2 | 30 | 0 | 0 | 0 |
| content/farmer/scenes.json | scene | 20 | 283 | 0 | 0 | 0 |

## Dialogue lines per role

The Bible asks for 15 to 20 lines a role.

| Role | Lines | Against the target |
| --- | --- | --- |
| spouse | 19 | within |
| neighbour | 15 | within |

## Errors

None.

## Warnings

None.

## Voice hits

None.
