"""Archive closed v0.71.1 evidence; only this final-proofs directory is written."""
from __future__ import annotations
import argparse, gzip, hashlib, io, json, os, tarfile, subprocess
from pathlib import Path

ROOT=Path('/workspace/scratch/68d171ec368e/hearth-and-oath')
BASE=ROOT/'artifacts/farmer-v0711'
OUT=BASE/'final-proofs'
ARCHIVE=OUT/'farmer-v0711-proofs.tar.gz'
MANIFEST=OUT/'farmer-v0711-proof-manifest.json'
EXPECTED='c369b934cb8a1abeeed04ee69b6db39bf7e32ee1'
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_text())

def stamp(p):
 s=p.stat();return(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
def read_stable(p):
 if p.is_symlink() or not p.is_file():raise ValueError('Not a regular proof file: '+str(p))
 old=stamp(p);data=p.read_bytes()
 if stamp(p)!=old:raise ValueError('Proof changed while reading: '+str(p))
 return data,old

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--all-guards-closed',required=True,action='store_true');ap.parse_args()
 freeze=load(BASE/'freeze.json');fast=load(BASE/'fast/report.json');slow=load(BASE/'slow/report.json');offline=load(BASE/'offline/report.json');offline_seals=load(BASE/'offline/output-seals.json')
 if freeze['commit']!=EXPECTED or freeze['version']!='0.71.1':raise ValueError('Unexpected frozen release.')
 snapshots=[]
 for name,report,count in [('FAST',fast,243),('SLOW',slow,36)]:
  if not report.get('finishedAt') or len(report['tests'])!=count or report['summary']['filesNotRun']!=0:raise ValueError(name+' lane is not completely closed.')
  if report['immutableSourceStatus']!='PASS' or report['immutableOutputStatus']!='PASS' or report.get('inputError') or report.get('outputChanges'):raise ValueError(name+' final guard did not pass.')
  for snap in [report['source'],report['after']]:
   if snap['git']['head']!=EXPECTED:raise ValueError(name+' HEAD differs from freeze.')
   for key in ['runtime','verification','offline']:
    if snap[key]!=freeze[key]:raise ValueError(name+' '+key+' differs from freeze.')
  snapshots.append({'lane':name,'source':report['source'],'after':report['after']})
 if offline['selectedRun']!='run-b' or offline['selectedPass']!=4 or offline['selectedFail']!=0 or len(offline['notRun'])!=26 or offline['full30Certification'] is not False:raise ValueError('Targeted offline scope differs.')
 if not offline_seals['allSelectedProcessesClosed'] or not offline_seals['selectedRecordedSealsMatch']:raise ValueError('Selected offline outputs are not closed and sealed.')
 if load(BASE/'offline/run-a/aux-integrity.json')['status']!='AUXILIARY SEAL FAIL':raise ValueError('Historical run A discrepancy must remain recorded.')
 for rec in offline_seals['files']:
  data,_=read_stable(BASE/'offline'/rec['file'])
  if len(data)!=rec['bytes'] or sha(data)!=rec['sha256']:raise ValueError('Offline copied proof differs from its published seal: '+rec['file'])
 files={}
 def add(relative):
  p=ROOT/relative;data,meta=read_stable(p);name=Path(relative).as_posix()
  if name.startswith('/') or '..' in Path(name).parts:raise ValueError('Unsafe archive path.')
  if len(data)>25*1024*1024:raise ValueError('Unexpected large build/media file: '+name)
  if name in files:
   if files[name]['data']!=data:raise ValueError('Path collision differs: '+name)
   return
  files[name]={'data':data,'source':p,'stamp':meta}
 def verify_seal(rec):
  p=Path(rec.get('path',rec.get('file','')))
  if not p.is_absolute():p=ROOT/p
  data,_=read_stable(p);size=rec.get('bytes',rec.get('metadata',{}).get('bytes'))
  if size is not None and len(data)!=size:raise ValueError('Recorded proof byte count differs: '+str(p))
  if sha(data)!=rec['sha256']:raise ValueError('Recorded proof checksum differs: '+str(p))
  add(p.relative_to(ROOT).as_posix())
 for label,report in [('fast',fast),('slow',slow)]:
  directory=BASE/label
  for row in report['tests']:
   if not row.get('processCompleted') or not row.get('actualProcess',{}).get('processCompleted'):raise ValueError('Missing actual process close proof: '+row['file'])
   for rec in row['evidence']:verify_seal(rec)
   stem=row['file'].replace('/','_')
   add((directory/(stem+'.completion.json')).relative_to(ROOT).as_posix())
  for p in sorted(directory.iterdir()):
   # Progress/transport append logs are not assertion evidence. Preserve only
   # sealed per-file records plus closed JSON/control programs and baselines.
   if p.is_file() and (p.suffix in ['.json','.mjs'] or p.name=='summary.md') and p.name!='checkpoint.partial.json':add(p.relative_to(ROOT).as_posix())
 for name in ['opening-final','annual-contribution-final']:
  report=load(BASE/name/'report.json')
  if report['status']!='PASS' or report['immutableSourceStatus']!='PASS' or report['immutableOutputStatus']!='PASS':raise ValueError('Preflight did not close cleanly.')
  for rec in report['evidence']:verify_seal(rec)
  for p in sorted((BASE/name).iterdir()):
   if p.is_file():add(p.relative_to(ROOT).as_posix())
 for name in ['offline','browser']:
  for p in sorted((BASE/name).rglob('*')):
   if p.is_file():
    if p.suffix not in ['.json','.jsonl','.log','.mjs','.py','.md','.jpg']:raise ValueError('Unexpected file in proof directory: '+str(p))
    add(p.relative_to(ROOT).as_posix())
 for name in ['freeze.json','benchmark.txt','build.txt']:
  add((BASE/name).relative_to(ROOT).as_posix())
 for name in ['artifacts/content-validation/report.json','artifacts/content-validation/report.md','artifacts/voice-lint/voice-lint.json','artifacts/voice-lint/voice-lint.md','dist/offline/manifest.json','dist/offline/recipe.json','artifacts/farmer-v0711/final-proofs/package.py']:
  add(name)
 fixture=offline['openingFixture'];fixture_path=ROOT/fixture['file']
 if fixture_path.stat().st_size!=fixture['bytes'] or sha(fixture_path.read_bytes())!=fixture['sha256']:raise ValueError('Captured opening fixture differs from its independent guard.')
 fixture_bindings=[]
 for name in ['common-freeholder-age16.json','bound-tenant-age16.json']:
  relative='docs/playtests/farmer-v071/'+name
  git_blob=subprocess.check_output(['git','rev-parse',EXPECTED+':'+relative],cwd=ROOT,text=True).strip()
  frozen_bytes=subprocess.check_output(['git','cat-file','blob',git_blob],cwd=ROOT)
  current_bytes,_=read_stable(ROOT/relative)
  if current_bytes!=frozen_bytes:raise ValueError('Consumed opening fixture differs from its exact C3 Git blob: '+relative)
  fixture_bindings.append({'file':relative,'frozenCommit':EXPECTED,'gitBlob':git_blob,'bytes':len(current_bytes),'sha256':sha(current_bytes)})
  add(relative)
 if load(ROOT/'artifacts/voice-lint/voice-lint.json')['version']!='0.71.1':raise ValueError('Voice audit is not current v0.71.1.')
 preflights=[{'directory':name,'before':load(BASE/name/'report.json')['before'],'after':load(BASE/name/'report.json')['after'],'status':load(BASE/name/'report.json')['status']} for name in ['opening-final','annual-contribution-final']]
 counts={key:sum(r.get(key,0) for report in [fast,slow] for r in report['tests']) for key in ['passed','failed','skipped']}
 readme=f'''# Hearth & Oath v0.71.1 closed proofs\n\nFrozen source: {EXPECTED}.\nFAST: {fast['summary']['passed']} passed, {fast['summary']['failed']} failed, {fast['summary']['skipped']} skipped.\nSLOW: {slow['summary']['passed']} passed, {slow['summary']['failed']} failed, {slow['summary']['skipped']} skipped.\nSkips remain skips and prevent strict test-lane PASS. The formal complete\nsoftware gate was not run/certified: targeted offline run B passed four checks;\nthe other twenty-six remain NOT RUN. No human farmer-playtest verdict is claimed.\n\nOriginal offline run A and its AUXILIARY SEAL FAIL are preserved separately.\nIts semantic passes are not promoted as clean selected proof. Run B is the\nselected immutable four-check run and uses the declared native/legacy scope.\nMemory statistics are Linux wait4 per-process high-water data, not aggregate\nsubtree RSS. See the raw offline report for the precise limits.\n\nopening-final/ and annual-contribution-final/ are pre-C3 preflights with their\nown dirty 8af7... HEAD and verification fingerprints. They are not the clean\nc369... lane run and their cases are not added again to FAST/SLOW totals.\nBoth old age-16 opening fixtures consumed by the new FAST test are supplied at\ntheir exact C3 Git blobs, with independent SHA256/byte bindings in the manifest.\nThis supplies consumed inputs; it is not an additional gameplay test.\n\nInternal artifacts/... paths are preserved. Strip the primary absolute root\nlisted in proof-path-map.json when resolving archived proof paths. The large\nHTML/game parts, artwork/music, source tar and Site archive are omitted. The\nsmall actual browser JPEGs and their JSON measurements are included. Manifest\nand recipe files are build records, not the full executable download.\n\nOnly closed, hash-checked per-file assertion outputs and their final guards are\nselected for the lanes. Progress and transport-live append logs are excluded.\nTar owners, permissions and timestamps are normalized; gzip uses epoch time\nand no original filename. All members are read back after deterministic builds.\n'''.encode()
 pathmap={'schemaVersion':1,'absoluteWorkspaceRoots':{str(ROOT):'.'},'rule':'Strip one listed root prefix and retain artifacts/... paths. Source and interpreter references outside artifacts/ refer to the repository/runtime, not files in this proof archive.'}
 files['README.md']={'data':readme,'source':None,'stamp':None}
 files['proof-path-map.json']={'data':(json.dumps(pathmap,sort_keys=True,indent=2)+'\n').encode(),'source':None,'stamp':None}
 index=[{'path':name,'bytes':len(row['data']),'sha256':sha(row['data'])} for name,row in sorted(files.items())]
 files['proof-inventory.json']={'data':(json.dumps({'schemaVersion':1,'scope':'This internal member list excludes its own recursive hash. The external manifest lists every member.','members':index},sort_keys=True,indent=2)+'\n').encode(),'source':None,'stamp':None}
 inventory=[{'path':name,'bytes':len(row['data']),'sha256':sha(row['data'])} for name,row in sorted(files.items())]
 def build(p):
  with p.open('wb') as raw:
   with gzip.GzipFile(filename='',mode='wb',fileobj=raw,compresslevel=9,mtime=0) as zipped:
    with tarfile.open(fileobj=zipped,mode='w|',format=tarfile.USTAR_FORMAT) as tar:
     for name,row in sorted(files.items()):
      info=tarfile.TarInfo(name);info.size=len(row['data']);info.mode=0o644;info.uid=0;info.gid=0;info.uname='';info.gname='';info.mtime=0
      tar.addfile(info,io.BytesIO(row['data']))
   raw.flush();os.fsync(raw.fileno())
 a=ARCHIVE.with_name(ARCHIVE.name+'.tmp');b=ARCHIVE.with_name(ARCHIVE.name+'.repeat.tmp');build(a);build(b);data=a.read_bytes()
 if data!=b.read_bytes():raise ValueError('Independent deterministic builds differ.')
 with tarfile.open(a,'r:gz') as tar:
  if tar.getnames()!=sorted(files):raise ValueError('Archive inventory differs.')
  for member in tar:
   if not member.isfile() or member.mode!=0o644 or member.uid!=0 or member.gid!=0 or member.mtime!=0:raise ValueError('Archive metadata differs.')
   if tar.extractfile(member).read()!=files[member.name]['data']:raise ValueError('Member byte mismatch: '+member.name)
 for row in files.values():
  if row['source'] is not None:
   if stamp(row['source'])!=row['stamp'] or row['source'].read_bytes()!=row['data']:raise ValueError('Closed source proof changed while packaging.')
 a.replace(ARCHIVE);b.unlink()
 manifest={'schemaVersion':1,'version':'0.71.1','archive':{'path':'docs/measures/farmer-v0711-proofs.tar.gz','stagedPath':str(ARCHIVE.relative_to(ROOT)),'bytes':len(data),'sha256':sha(data),'format':'deterministic USTAR in gzip','gzipMtime':0,'normalizedMemberMtime':0,'determinismCheck':'Two independent builds were byte-identical.','readback':'Every member matched its selected input bytes.'},'statuses':{'strictTestLanesStatus':'FAIL' if counts['failed'] or counts['skipped'] else 'PASS','formalFullSoftwareGate':'NOT RUN','fullThirtyOfflineCertification':False,'targetedOfflineSelectedRun':'run-b','targetedOfflinePassed':4,'targetedOfflineNotRun':26,'historicalOfflineRunA':'AUXILIARY SEAL FAIL','humanFarmerPlaytest':'NOT RUN'},'fast':fast['summary'],'slow':slow['summary'],'testLaneCaseTotals':counts,'freeze':freeze,'preC3Preflights':preflights,'consumedOpeningFixtures':fixture_bindings,'memberCount':len(inventory),'uncompressedBytes':sum(r['bytes'] for r in inventory),'pathMap':pathmap,'members':inventory,'limits':['No active logs or partial lane checkpoints are packaged.','Pre-C3 preflights are separate provenance and not added again to totals.','Targeted offline run A discrepancy is preserved; only clean B is selected.','Large HTML/media/parts/source and Site archives are excluded.']}
 MANIFEST.write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
 print(json.dumps({'archive':str(ARCHIVE),'bytes':len(data),'sha256':sha(data),'manifest':str(MANIFEST),'manifestSha256':sha(MANIFEST.read_bytes()),'members':len(inventory),'uncompressedBytes':manifest['uncompressedBytes'],'statuses':manifest['statuses']}))

if __name__=='__main__':main()
