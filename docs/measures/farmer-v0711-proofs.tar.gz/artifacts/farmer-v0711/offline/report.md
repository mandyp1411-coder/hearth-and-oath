Four targeted offline checks PASS for v0.71.1. All four selected proofs come from clean immutable run B. The other 26 offline checkers were NOT RUN for this patch; this is not an all-30 or full-lane certification.

| Checker | Seconds | Exit | Kernel wait4 max RSS (KiB) |
|---|---:|---:|---:|
| verify-offline-module-startup-v71 | 17.412 | 0 | 1869468 |
| verify-offline-interface-v40 | 102.306 | 0 | 3475728 |
| verify-offline-creation-qol-v580 | 35.700 | 0 | 2163648 |
| verify-offline-life-context-v59 | 17.411 | 0 | 2037504 |

Commit: c369b934cb8a1abeeed04ee69b6db39bf7e32ee1

Runtime: cee3675cd16e1883722a69d8f6e015689c72fe381e1043b767d0a7bfd2e9b926

Verification: 7f9f074416c77be6a75ed789b11a65d0f1f09fa34cb4d22cfffbcaebabf2d89c

Artifact: 5f7dc2ea79789a4c5f1e656bf8b2b4fbaa3a4c5808497c02fd3cb99b0783b79f

HEAD, runtime, verification, artifact, engine, shared helper and all four checker hashes matched before/after every check. The referenced docs/playtests/farmer-v071/common-freeholder-age16.json is separately byte/hash guarded and matches its frozen Git blob; the ordinary verification-tree hash excludes docs/.

The native check covers the actual old opening captions and saved care/gift, ambition, Book, exact export, adult fee 3 plus household keep 1 with full 100→96 command parity, all three saved states/backups, native JSON and module-private bindings. The other three checks retain their explicit legacy/shared-asset limitations. Browser and human playtesting remain separate.

Run A is retained unchanged with four semantic passes and an auxiliary memory-sample seal failure. It is not selected. The artifact-only runner removed unsupported /proc sampling, then reran all four as B. All B stdout, stderr and wait4 resource files are closed and their recorded seals match. No code/checker/test/build inputs changed.

Memory numbers are kernel wait4 per-process high-water accounting, not total process-tree RSS. There were no checker timeouts, signals or OOM failures.
