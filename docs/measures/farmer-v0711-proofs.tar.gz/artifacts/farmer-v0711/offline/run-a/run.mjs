import assert from 'node:assert/strict';
import {readFile,writeFile,readdir,stat} from 'node:fs/promises';
import {createWriteStream} from 'node:fs';
import {spawn,execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {runtimeIdentity,verificationIdentity,validateOfflineIdentity,hashFile,sha256} from '../../../scripts/lib/release-identity.mjs';
const root=fileURLToPath(new URL('../../../',import.meta.url)),out=fileURLToPath(new URL('.',import.meta.url));
const frozen=JSON.parse(await readFile(out+'freeze.json','utf8'));
const helper='scripts/lib/offline-module-vm.mjs',fixture='docs/playtests/farmer-v071/common-freeholder-age16.json';
const selected=['scripts/verify-offline-module-startup-v71.mjs','scripts/verify-offline-interface-v40.mjs','scripts/verify-offline-creation-qol-v580.mjs','scripts/verify-offline-life-context-v59.mjs'];
const all=(await readdir(root+'scripts')).filter(f=>/^verify-offline.*\.mjs$/.test(f)).map(f=>'scripts/'+f).sort();assert.equal(all.length,30);
const head=()=>execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim();
const fixtureGitBytes=execFileSync('git',['show',`${frozen.commit}:${fixture}`],{cwd:root,maxBuffer:16*1024*1024});
const fixtureGit={file:fixture,gitBlob:execFileSync('git',['rev-parse',`${frozen.commit}:${fixture}`],{cwd:root,encoding:'utf8'}).trim(),bytes:fixtureGitBytes.length,sha256:sha256(fixtureGitBytes)};
const row=async file=>({file,bytes:(await stat(root+file)).size,sha256:await hashFile(root+file)});
async function snapshot(){return {head:head(),runtime:await runtimeIdentity(root),verification:await verificationIdentity(root),offline:await validateOfflineIdentity(root),engine:await row('dist/js/engine.js'),helper:await row(helper),checkers:await Promise.all(selected.map(row)),openingFixture:await row(fixture)};}
const initial=await snapshot();
assert.equal(initial.head,frozen.commit);assert.deepEqual(initial.runtime,frozen.runtime);assert.deepEqual(initial.verification,frozen.verification);assert.deepEqual(initial.offline,frozen.offline);assert.equal(initial.engine.sha256,frozen.engineSha256);assert.deepEqual(initial.openingFixture,{file:fixture,bytes:fixtureGit.bytes,sha256:fixtureGit.sha256});
const assertInput=value=>assert.deepEqual(value,initial,'HEAD/runtime/verification/artifact/engine/helper/checkers/opening-fixture remain frozen');
const infrastructure=await Promise.all(['artifacts/farmer-v0711/offline/run.mjs','artifacts/farmer-v0711/offline/wait4-command.py','artifacts/farmer-v0711/offline/freeze.json'].map(row));
const summary={version:frozen.version,scope:'Four targeted offline semantic checkers only for v0.71.1; other26explicitly NOT RUN.',startedAt:new Date().toISOString(),status:'running',initial,fixtureGit,infrastructure,selected,notRun:all.filter(file=>!selected.includes(file)).map(file=>({script:file,status:'NOT RUN',reason:'Outside the authorized four-check v0.71.1 targeted scope.'})),command:['node','--max-old-space-size=2048','--expose-gc','<checker>'],timeoutMs:900000,checks:[],memoryLimits:'wait4per-processhigh-wateraccountingplussampled500msdescendantsum;notclaimingexactaggregatepeak.'};
await writeFile(out+'summary.json',JSON.stringify(summary,null,2)+'\n');
const maybeJson=async file=>{try{return JSON.parse(await readFile(file,'utf8'));}catch{return null;}};
async function cgroup(){const result={};for(const file of ['/sys/fs/cgroup/memory.events','/sys/fs/cgroup/memory.current','/sys/fs/cgroup/memory.max'])try{result[file]=String(await readFile(file,'utf8')).trim();}catch{}return result;}
async function processes(){const rows=[];for(const entry of await readdir('/proc')){if(!/^\d+$/.test(entry))continue;try{const text=await readFile('/proc/'+entry+'/status','utf8'),get=key=>Number(text.match(new RegExp('^'+key+':\\s*(\\d+)','m'))?.[1]||0);rows.push({pid:Number(entry),ppid:get('PPid'),name:text.match(/^Name:\s*(.*)$/m)?.[1]||'',rssKiB:get('VmRSS'),hwmKiB:get('VmHWM')});}catch{}}return rows;}
for(const script of selected){
 assertInput(await snapshot());const began=Date.now(),name=path.basename(script,'.mjs');
 const entry={script,startedAt:new Date().toISOString(),timeout:false,stdout:name+'.stdout.log',stderr:name+'.stderr.log',resources:name+'.resources.json',memory:name+'.memory.jsonl',cgroupBefore:await cgroup()};
 console.log('START '+script);
 const stdout=createWriteStream(out+entry.stdout),stderr=createWriteStream(out+entry.stderr),memory=createWriteStream(out+entry.memory);
 const child=spawn('python3',[out+'wait4-command.py',out+entry.resources,process.execPath,'--max-old-space-size=2048','--expose-gc',script],{cwd:root,detached:true,stdio:['ignore','pipe','pipe']});child.stdout.pipe(stdout,{end:false});child.stderr.pipe(stderr,{end:false});
 let sampling=false,samples=0,maxAggregateRssKiB=0,maxObservedHwmKiB=0,peakProcessRows=[];
 async function sample(){if(sampling)return;sampling=true;try{const rows=await processes(),ids=new Set([child.pid]);let changed=true;while(changed){changed=false;for(const row of rows)if(ids.has(row.ppid)&&!ids.has(row.pid)){ids.add(row.pid);changed=true;}}const family=rows.filter(row=>ids.has(row.pid));const total=family.reduce((n,row)=>n+row.rssKiB,0);maxObservedHwmKiB=Math.max(maxObservedHwmKiB,...family.map(row=>row.hwmKiB));if(total>maxAggregateRssKiB){maxAggregateRssKiB=total;peakProcessRows=family;}memory.write(JSON.stringify({elapsedMs:Date.now()-began,aggregateRssKiB:total,processes:family})+'\n');samples++;}finally{sampling=false;}}
 await sample();const memoryTimer=setInterval(()=>sample().catch(error=>{entry.memorySampleError=String(error);}),500);
 let hardKill;const timer=setTimeout(()=>{entry.timeout=true;try{process.kill(-child.pid,'SIGTERM');}catch{}hardKill=setTimeout(()=>{try{process.kill(-child.pid,'SIGKILL');}catch{}},10000);},summary.timeoutMs);
 const result=await new Promise(resolve=>{child.on('error',error=>resolve({code:null,signal:null,error:String(error)}));child.on('close',(code,signal)=>resolve({code,signal}));});
 clearInterval(memoryTimer);clearTimeout(timer);if(hardKill)clearTimeout(hardKill);while(sampling)await new Promise(resolve=>setTimeout(resolve,10));
 await Promise.all([stdout,stderr,memory].map(stream=>new Promise(resolve=>stream.end(resolve))));
 Object.assign(entry,result,{durationMs:Date.now()-began,endedAt:new Date().toISOString(),memoryCapture:{samples,sampledPeakAggregateRssKiB:maxAggregateRssKiB,maxObservedProcessHwmKiB:maxObservedHwmKiB,peakProcessRows},wait4:await maybeJson(out+entry.resources),cgroupAfter:await cgroup()});
 entry.status=result.code===0&&!entry.timeout?'PASS':'FAIL';
 entry.seals=[];for(const file of [entry.stdout,entry.stderr,entry.memory,entry.resources])try{entry.seals.push({file,bytes:(await stat(out+file)).size,sha256:await hashFile(out+file)});}catch{entry.seals.push({file,missing:true});}
 try{assertInput(await snapshot());entry.inputsUnchanged=true;}catch(error){entry.inputsUnchanged=false;entry.inputError=String(error);summary.status='stopped-input-changed';}
 summary.checks.push(entry);await writeFile(out+'summary.json',JSON.stringify(summary,null,2)+'\n');
 console.log(JSON.stringify({script,status:entry.status,durationMs:entry.durationMs,code:entry.code,signal:entry.signal,timeout:entry.timeout,sampledPeakAggregateRssKiB:maxAggregateRssKiB,wait4MaxRssKiB:entry.wait4?.usage?.maxRssKiB,inputsUnchanged:entry.inputsUnchanged}));
 if(entry.inputsUnchanged===false)break;
}
summary.final=await snapshot();assertInput(summary.final);assert.deepEqual(await Promise.all(infrastructure.map(info=>row(info.file))),infrastructure,'runner infrastructure unchanged');summary.endedAt=new Date().toISOString();summary.passed=summary.checks.filter(row=>row.status==='PASS').length;summary.failed=summary.checks.filter(row=>row.status==='FAIL').length;if(summary.status==='running')summary.status=summary.checks.length===4&&summary.failed===0?'PASS':'FAIL';summary.gitStatus=execFileSync('git',['status','--short'],{cwd:root,encoding:'utf8'}).trim();
await writeFile(out+'summary.json',JSON.stringify(summary,null,2)+'\n');console.log(JSON.stringify({status:summary.status,passed:summary.passed,failed:summary.failed,selected:4,notRun:summary.notRun.length}));process.exitCode=summary.status==='PASS'?0:1;
