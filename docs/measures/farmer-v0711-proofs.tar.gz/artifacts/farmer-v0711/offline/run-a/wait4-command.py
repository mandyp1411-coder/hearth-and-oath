import os,sys,json,time,signal
resource_file=sys.argv[1];command=sys.argv[2:];started=time.monotonic()
pid=os.fork()
if pid==0:
 try:os.execv(command[0],command)
 except BaseException as exc:
  print(str(exc),file=sys.stderr,flush=True);os._exit(127)
_,status,usage=os.wait4(pid,0)
result={'pid':pid,'command':command,'wallSeconds':time.monotonic()-started,'waitStatus':status,'exitCode':os.waitstatus_to_exitcode(status),'usage':{'userSeconds':usage.ru_utime,'systemSeconds':usage.ru_stime,'maxRssKiB':usage.ru_maxrss,'minorFaults':usage.ru_minflt,'majorFaults':usage.ru_majflt,'swaps':usage.ru_nswap,'voluntarySwitches':usage.ru_nvcsw,'involuntarySwitches':usage.ru_nivcsw},'scope':'Linux wait4 usage for the direct checker process, including waited descendant accounting; maxRss is a per-process high-water value, not aggregate subtree RSS.'}
with open(resource_file,'w') as stream:json.dump(result,stream,indent=2);stream.write('\n')
if os.WIFSIGNALED(status):
 sig=os.WTERMSIG(status);signal.signal(sig,signal.SIG_DFL);os.kill(os.getpid(),sig);os._exit(128+sig)
sys.exit(os.WEXITSTATUS(status))
