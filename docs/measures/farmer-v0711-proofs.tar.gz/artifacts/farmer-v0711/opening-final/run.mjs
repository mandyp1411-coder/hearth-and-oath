import {spawn} from 'node:child_process';
import {readFile,writeFile,stat} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {runtimeIdentity,verificationIdentity,gitIdentity,hashFile} from '../../../scripts/lib/release-identity.mjs';
import {parseTestResults} from '../../../scripts/lib/release-contract.mjs';
const root=fileURLToPath(new URL('../../../',import.meta.url)),out=fileURLToPath(new URL('.',import.meta.url));
const file='tests/farmer-opening.test.js',helper=root+'artifacts/farmer-v071/slow-b-recheck/capture-test.mjs';
const paths={tap:out+'tests_farmer-opening.test.js.tap',process:out+'tests_farmer-opening.test.js.process.json',results:out+'tests_farmer-opening.test.js.results.jsonl',stderr:out+'capture.stderr.log'};
const snapshot=async()=>({runtime:await runtimeIdentity(root),verification:await verificationIdentity(root),git:gitIdentity(root),testSha256:await hashFile(root+file),helperSha256:await hashFile(helper)});
const startedAt=new Date().toISOString(),before=await snapshot(),args=[helper,paths.tap,paths.process,file],stdout=[],stderr=[];
const child=spawn(process.execPath,args,{cwd:root,env:process.env,stdio:['ignore','pipe','pipe']});let error=null;
child.stdout.on('data',b=>stdout.push(b));child.stderr.on('data',b=>stderr.push(b));child.on('error',e=>error=String(e));
const [code,signal]=await new Promise(resolve=>child.on('close',(code,signal)=>resolve([code,signal])));
await writeFile(paths.results,Buffer.concat(stdout),{flag:'wx'});await writeFile(paths.stderr,Buffer.concat(stderr),{flag:'wx'});
const actual=JSON.parse(await readFile(paths.process,'utf8')),resultsText=await readFile(paths.results,'utf8'),tapText=await readFile(paths.tap,'utf8'),stats=parseTestResults(resultsText);
const match=tapText.match(/(?:^|\n)1\.\.(\d+)\n# tests (\d+)\n# suites (\d+)\n# pass (\d+)\n# fail (\d+)\n# cancelled (\d+)\n# skipped (\d+)\n# todo (\d+)\n# duration_ms ([0-9.]+)\s*$/);
const keys=['plan','tests','suites','passed','failed','cancelled','skipped','todo','durationMs'],tap=match?Object.fromEntries(keys.map((k,i)=>[k,Number(match[i+1])])):null;
function metadata(s){return {dev:s.dev,ino:s.ino,bytes:s.size,birthtimeMs:s.birthtimeMs,mtimeMs:s.mtimeMs,ctimeMs:s.ctimeMs};}
async function seal(path){const a=metadata(await stat(path)),sha256=await hashFile(path),b=metadata(await stat(path));if(JSON.stringify(a)!==JSON.stringify(b))throw Error('Evidence changed while sealing: '+path);return {path:path.slice(root.length),sha256,metadata:b};}
const evidence=[];for(const path of Object.values(paths))evidence.push(await seal(path));
const after=await snapshot(),immutableSourceStatus=JSON.stringify(before)===JSON.stringify(after)?'PASS':'FAIL';
const testStatus=code===0&&!signal&&!error&&actual.code===0&&!actual.signal&&!actual.error&&actual.processCompleted&&tap&&tap.plan===8&&tap.tests===8&&tap.passed===8&&!tap.failed&&!tap.cancelled&&!tap.skipped&&!tap.todo&&stats.passed===8&&!stats.failed&&!stats.skipped&&stats.results===8?'PASS':'FAIL';
const outputChanges=[];for(const old of evidence)if(JSON.stringify(old)!==JSON.stringify(await seal(root+old.path)))outputChanges.push(old.path);
const report={schemaVersion:1,status:testStatus==='PASS'&&immutableSourceStatus==='PASS'&&!outputChanges.length?'PASS':'FAIL',scope:'One full eight-case test file, exact runtime and verification bytes; this is a leaf recheck, not a complete release gate.',file,startedAt,completedAt:new Date().toISOString(),before,after,testStatus,immutableSourceStatus,immutableOutputStatus:outputChanges.length?'FAIL':'PASS',outputChanges,wrapper:{command:[process.execPath,...args],pid:child.pid,code,signal,error,capture:'Outer wrapper output retained in memory until actual child close; inner wrapper retains JSONL/TAP until Node child close.'},actualProcess:actual,stats,tap,evidence};
await writeFile(out+'report.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({status:report.status,testStatus,immutableSourceStatus,immutableOutputStatus:report.immutableOutputStatus,passed:stats.passed,failed:stats.failed,skipped:stats.skipped,durationMs:tap?.durationMs}));process.exitCode=report.status==='PASS'?0:1;
