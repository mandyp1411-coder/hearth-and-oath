# v0.71.1 full SLOW lane

All 36 official files ran serially on frozen commit c369b934cb8a1abeeed04ee69b6db39bf7e32ee1, without historical result reuse. Actual Node results: **741 passed, 0 failed, 1 skipped**; 0 cancelled. All actual Node file processes closed and exited zero.

The strict classifier reports **FAIL** because the original source-art geometry test is skipped. Runtime, verification inputs, HEAD, version and standalone identity stayed unchanged. All 144 closed proof output sizes and SHA-256 hashes passed an independent check.

- tests/rpg-v18.test.js: all 384 enemy cells are real registered illustrations with truthful species bindings — reference-art/ is not present in this checkout
