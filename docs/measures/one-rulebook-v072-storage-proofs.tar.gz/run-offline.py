import subprocess,json,hashlib,time,os,signal
from pathlib import Path
root=Path.cwd();out=root/'artifacts/one-rulebook-v072/admission'
def snapshot():
 paths=subprocess.check_output(['git','ls-files','-z']).decode().strip('\0').split('\0')
 rows=[(p,len((b:=(root/p).read_bytes())),hashlib.sha256(b).hexdigest()) for p in paths]
 return {'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],text=True).strip(),'trackedSha256':hashlib.sha256(json.dumps(rows,separators=(',',':')).encode()).hexdigest(),'files':len(rows)}
before=snapshot();assert before['status']=='',before
command=['node','--experimental-vm-modules','scripts/verify-offline-module-startup-v71.mjs'];start=time.monotonic();expired=False
with (out/'offline.stdout').open('wb') as stdout,(out/'offline.stderr').open('wb') as stderr:
 child=subprocess.Popen(command,stdout=stdout,stderr=stderr,start_new_session=True)
 try:code=child.wait(timeout=180)
 except subprocess.TimeoutExpired:
  expired=True;os.killpg(child.pid,signal.SIGTERM)
  try:code=child.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait()
after=snapshot();data=(out/'offline.stdout').read_text();decoder=json.JSONDecoder();documents=[];parse_error=None
try:
 while data.strip():
  data=data.lstrip();value,end=decoder.raw_decode(data);documents.append(value);data=data[end:]
except Exception as error:parse_error=str(error)
final=documents[-1] if documents else None
report={'scope':'One exact compiled standalone SourceTextModule semantic checker; not browser layout, archive transfer or human playtest. Other offline checkers NOT RUN.','command':command,'before':before,'after':after,'immutableTrackedSource':before==after,'actualNodeExit':code,'expired':expired,'elapsedMs':round((time.monotonic()-start)*1000),'stdoutJsonDocuments':documents,'stdoutParseError':parse_error,'raw':{p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [out/'offline.stdout',out/'offline.stderr']}}
report['status']='PASS' if code==0 and not expired and before==after and parse_error is None and isinstance(final,dict) and final.get('status')=='PASS' and len(final.get('cases',[]))==14 else 'FAIL'
(out/'offline-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
raise SystemExit(0 if report['status']=='PASS' else 1)
