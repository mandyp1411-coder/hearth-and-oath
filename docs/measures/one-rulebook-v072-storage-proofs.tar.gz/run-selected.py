import subprocess,json,hashlib,time,os,signal
from pathlib import Path
root=Path.cwd(); out=root/'artifacts/one-rulebook-v072/admission'
files=sorted(p.as_posix() for p in Path('tests').glob('*.test.js') if p.name.startswith(('save','ironman','one-rulebook','edition-v70','archive-link')))
def snapshot():
 paths=subprocess.check_output(['git','ls-files','-z']).decode().strip('\0').split('\0')
 rows=[(p,len((b:=(root/p).read_bytes())),hashlib.sha256(b).hexdigest()) for p in paths]
 return {'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],text=True).strip(),'trackedSha256':hashlib.sha256(json.dumps(rows,separators=(',',':')).encode()).hexdigest(),'files':len(rows)}
before=snapshot(); assert before['status']=='',before
command=['node','--test','--test-concurrency=1','--test-reporter=./scripts/lib/release-reporter.mjs',*files]
print(json.dumps({'started':True,'files':len(files),'head':before['head']}),flush=True)
start=time.monotonic(); expired=False
with (out/'selected.jsonl').open('wb') as stdout,(out/'selected.stderr').open('wb') as stderr:
 child=subprocess.Popen(command,stdout=stdout,stderr=stderr,start_new_session=True)
 try: code=child.wait(timeout=900)
 except subprocess.TimeoutExpired:
  expired=True; os.killpg(child.pid,signal.SIGTERM)
  try: code=child.wait(timeout=10)
  except subprocess.TimeoutExpired: os.killpg(child.pid,signal.SIGKILL);code=child.wait()
after=snapshot(); rows=[json.loads(line) for line in (out/'selected.jsonl').read_text().splitlines() if line]
results=[r for r in rows if r['type'] in ('test:pass','test:fail')]
counts={'passed':sum(r['type']=='test:pass' and not r.get('skip') and not r.get('todo') for r in results),'failed':sum(r['type']=='test:fail' for r in results),'skipped':sum(bool(r.get('skip') or r.get('todo')) for r in results)}
report={'scope':'Selected current save, Ironman, edition and cutover tests, not full FAST/SLOW or release certification.','command':command,'before':before,'after':after,'immutableTrackedSource':before==after,'actualNodeExit':code,'expired':expired,'elapsedMs':round((time.monotonic()-start)*1000),'fileCount':len(files),'counts':counts,'raw':{p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [out/'selected.jsonl',out/'selected.stderr']},'failures':[r for r in results if r['type']=='test:fail']}
report['status']='PASS' if code==0 and not expired and before==after and counts['passed']>0 and counts['failed']==0 and counts['skipped']==0 else 'FAIL'
(out/'selected-report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)
raise SystemExit(0 if report['status']=='PASS' else 1)
